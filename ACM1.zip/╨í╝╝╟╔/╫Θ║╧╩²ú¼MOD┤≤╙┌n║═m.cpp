//#include<bits/stdc++.h>
//using namespace std;
//typedef long long ll;
//
//const ll MOD = 1e9 + 7;
//const int MAXN = 1e6;
//
//ll inv[MAXN + 5], fac[MAXN + 5], invfac[MAXN + 5];
//
//void init_C(int n) {
//    inv[1] = 1;
//    for(int i = 2; i <= n; i++)
//        inv[i] = inv[MOD % i] * (MOD - MOD / i) % MOD;
//    fac[0] = 1, invfac[0] = 1;
//    for(int i = 1; i <= n; i++) {
//        fac[i] = fac[i - 1] * i % MOD;
//        invfac[i] = invfac[i - 1] * inv[i] % MOD;
//    }
//}
//
//inline ll C(ll n, ll m) {
//    if(n < m)
//        return 0;
//    return fac[n] * invfac[n - m] % MOD * invfac[m] % MOD;
//}
//
//int main()
//{
//    init_C(1000);
//    while(1)
//    {
//        int n,r;
//        cin>>n>>r;
//        cout<<C(n,r)<<endl;
//    }
//}
//
