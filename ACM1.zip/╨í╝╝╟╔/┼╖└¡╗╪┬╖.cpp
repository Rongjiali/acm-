//////int ans[maxn];///maxn�Ǳߵ��������
//////bool vis[maxn];
//////int bj;
//////void dfs(int now)
//////{
//////    for(int i=head[now];i!=-1;i=tu[i].next)
//////    if(!vis[i])
//////    {
//////        vis[i]=1;
//////        vis[i^1]=1;///��������ŷ����·����һ���ò���д��䣬��Ϊ������˫��
//////        dfs(tu[i].to);
//////        ans[bj++]=i;///����i�Ǽ�¼�ߣ�����tu[i].to�Ǽ�¼��
//////    }
//////}
////////ģ��
////#include <iostream>
//////#include <stdio.h>
//////#include <stdlib.h>
//////#include<string.h>
//////#include<algorithm>
//////#include<math.h>
////////#include<queue>
//////#include<iomanip>
//////using namespace std;
//////const int N = 1000010;
//////int head[N];
//////
//////struct edgenode{
//////    int to;
//////    int next;
//////}tu[N];
//////
//////int  ip;
//////void init()
//////{
//////    ip = 0;
//////    memset(head,-1,sizeof(head));
//////}
//////void add(int u,int v)
//////{
//////    tu[++ip].to =v;
//////    tu[ip].next = head[u];
//////    head[u] = ip;
//////}
//////int ans[N];
//////bool vis[N];
//////int bj;
//////
//////void DFS(int now)
//////{
//////    for(int i = head[now];i!=-1;i = tu[i].next)//i�Ǳ�
//////    {
//////        if(!vis[i])
//////        {
//////            vis[i] =1;
//////            DFS(tu[i].to);
//////            ans[bj++] = tu[i].to;
//////        }
//////    }
//////}
//////int main()
//////{
//////    int m,n;
//////    scanf("%d%d",&n,&m);
//////    init();
//////    while(m--)
//////    {
//////        int a,b;
//////        scanf("%d%d",&a,&b);
//////        add(a,b);
//////        add(b,a);
//////    }
//////    memset(vis,0,sizeof(vis));
//////    memset(ans,0,sizeof(ans));
//////    bj = 0;
//////    DFS(1);
//////    for(int i=0;i<bj;i++)
//////        cout<<ans[i]<<endl;
//////    cout<<1<<endl;
//////    return 0;
//////}
////
////
//#include <cstdio>
//#include <queue>
//#include <cstring>
//#include <iostream>
//#include <cstdlib>
//#include <algorithm>
//#include <vector>
//#include <map>
//#include <string>
//#include <set>
//#include <ctime>
//#include <cmath>
//#include <cctype>
//using namespace std;
//#define maxn 50000+10
//#define maxm 10000+10
//#define LL long long
//int cas=1,T;
//int n,m;
//struct Edge
//{
//	int v;
//	bool vis;
//	Edge(){}
//    Edge(int v,bool vis):v(v),vis(vis){}
//}edges[maxm*2];
//vector<Edge>G[maxn];
//vector<int> ans;
//void init()
//{
//	for (int i = 0;i<=n;i++)
//		G[i].clear();
//}
//void euler(int u)
//{
//	for (int i = 0;i<G[u].size();i++)
//	{
//		Edge &e = G[u][i];
//		if (!e.vis)
//		{
//			e.vis=1;
//			euler(e.v);
//		}
//	}
//	ans.push_back(u);
//	//printf("%d\n",u);
//}
//int main()
//{
//	scanf("%d%d",&n,&m);
//	for (int i = 1;i<=m;i++)
//	{
//		int u,v;
//		scanf("%d%d",&u,&v);
//		G[u].push_back(Edge(v,false));
//		G[v].push_back(Edge(u,false));
//	}
//	euler(1);
//	for(int i=0;i<ans.size();i++)
//        printf("%d\n",ans[i]);
//	//freopen("in","r",stdin);
//	//scanf("%d",&T);
//	//printf("time=%.3lf",(double)clock()/CLOCKS_PER_SEC);
//	return 0;
//}
//
