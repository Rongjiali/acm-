//#include <iostream>
//#include<cstdio>
//#include<cstring>
//
//using namespace std;
//
//int a[210][210];
//
//int main()
//{
//    int n;
//    cin>>n;
//    int m=n*2+3;
//    memset(a,0,sizeof(a));
//    //�Ȼ���1/8;
//    for(int t=1;t<=n;t++)
//    {
//        int i = t*2 +1,j = t*2-1;
//        a[i][j] =a[i][j+1] = a[i][j+2] = 1;
//        for(;i<=m;i++)
//            a[i][j] =1;
//    }
//    a[m][m] = a[m][m-1] = a[m][m-2] =1;
//    //�����ϱߵ������ϱ�
//    for(int i=1;i<=m;i++)
//        for(int j=i;j<=m;j++)
//            a[i][j]=a[j][i];
//    //��ʣ�µ�3������
//    for(int i=1;i<=m;i++)
//        for(int j=1;j<=m;j++)
//        {
//            a[m+i][j]=a[m-i][j];
//            a[i][j+m]=a[i][m-j];
//            a[i+m][j+m]=a[m-i][m-j];
//        }
//    for(int i=1;i<=2*m-1;i++)
//    {
//        for(int j=1;j<=2*m-1;j++)
//            printf(a[i][j]==1?"$":".");
//        cout<<endl;
//    }
//}
