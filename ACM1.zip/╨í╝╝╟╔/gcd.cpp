//#include<bits/stdc++.h>
//using namespace std;
//typedef long long ll;
//
////ll  gcd1(ll a,ll b)
////{
////    if(b==0)
////        return a;
////    else
////        return gcd1(b,a%b);
////}
////ll  gcd2(ll a,ll b)
////{
////    while(a!=0 && b!=0)
////    {
////        if(a>b)
////            a%=b;
////        else
////            b%=a;
////    }
////    return max(a,b);
////}
//
//
//ll exgcd(ll a,ll b,ll& x,ll& y)
//{
//	if(!b)
//	{
//		x=1;
//		y=0;
//		return a;
//	}
//	ll t=exgcd(b,a%b,y,x);
//	y-=a/b*x;
//	return t;
//}
//bool linear_equation1(ll a,ll b,ll c,ll &x,ll &y)//����չŷ������㷨�ⲻ������ax+by=c;
//{
//    ll d=exgcd(a,b,x,y);
//    if(c%d)
//        return false;
//    ll k=c/d;
//    x*=k; y*=k;    //��õ�ֻ������һ���
//    return true;
//}
//
//bool linear_equation(ll a,ll b,ll c,ll &x,ll &y)//����x>0&&y>0����С��
//{
//    ll d=exgcd(a,b,x,y);
//    if(c%d)
//        return false;
//    ll k=c/d;
//    x*=k; y*=k;    //��õ�ֻ������һ���
//    ll b1 = b/d;
//    ll a1 = a/d;
//    ll i = 0;
//
//    //cout<<x<<" "<<y<<endl;
//    if(y<0){
//        while (y<=0){
//            y+=a1;
//            x-=b1;
//
//        }
//    }
//    while (y-a1>=0){
//        y-=a1;
//        x+=b1;
//    }
//    if(y>=0&&x>=0){
//        return true;
//    } else{
//        return false;
//    }
//
//}
//bool modular_linear_equation(ll a,ll b,ll n)//a*x = b(mod n);
//{
//    ll x,y,x0,i;
//    ll d=exgcd(a,n,x,y);
//    if(b%d)
//        return false;
//    x0=x*(b/d)%n;   //�ؽ�
//    cout<<d<<" "<<x0<<endl;
//    for(i=1;i<5;i++)
//        cout<<(x0+i*(n/d))<<endl;//��ļ��dx��n/d
//    return true;
//}
//bool modular_linear_equation2(ll a,ll b,ll n,ll &ans)//a*x = b(mod n),ans����С��x
//{
//    ll x,y,x0;
//    ll d=exgcd(a,n,x,y);
//    if(b%d)
//        return false;
//
//    ll s=n/d;
//	ans=(x*b/d%s+s)%s;
//    return true;
//}
//ll mod_reverse(ll a,ll n)//ax=1(mod n) ��a����Ԫx
//{
//    ll d,x,y;
//    d=exgcd(a,n,x,y);
//    if(d==1)
//        return (x%n+n)%n;
//    else
//        return -1;
//}
//
//int main()
//{
////    ll a,b,c,x,y;
////    cin>>a>>b>>c;
////    if(linear_equation(a,b,c,x,y))
////        cout<<x<<" a "<<y<<endl;
////    linear_equation1(a,b,c,x,y);
////        cout<<x<<" "<<y<<endl;
//    ll a,b,n;
//
//    cin>>a>>n;
//    //modular_linear_equation(a,b,n);
//    cout<<mod_reverse(a,n)<<endl;
//
//}
//
//
