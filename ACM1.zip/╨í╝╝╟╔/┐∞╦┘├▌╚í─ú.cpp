//#include <bits/stdc++.h>
//typedef long long ll;
//using namespace std;
//
//const int mod = 1e9 +7;

//int pow_mod(int a, int b)//a�ǵ�����b����
//{
//    int ans = 1;
//    for(;b;b>>=1)
//    {
//        if(b&1) ans = ans * a %mod;
//        a=a*a%mod;
//    }
//    return ans;
//}

//ll pow_mod2(ll a, ll b) {
//    ll res = 1;
//    for(; b; b >>= 1) {
//        if(b & 1) res = res * a % mod;
//        a = a * a % mod;
//    }
//    return res;
//}
//
//
//int main()
//{
//    int a,b;
//    cin>>a>>b;
//    //cout<<pow_mod(a,b)<<endl;
//    cout<<pow_mod2(a,b)<<endl;
//}

//����poj1995


//#include<cstdio>
//#include<cstring>
//#include<algorithm>
//#include<iostream>
//typedef long long ll;
//using namespace std;
//
//ll pow_mod(ll a, ll b,ll mod) {
//    ll res = 1;
//    for(; b; b >>= 1) {
//        if(b & 1) res = res * a % mod;
//        a = a * a % mod;
//    }
//    return res;
//}
//int main()
//{
//    int n;
//    ll m;
//    cin>>n;
//    while(n--)
//    {
//        int num;
//        cin>>m;
//        ll sum = 0;
//        cin>>num;
//        for(int i=0;i<num;i++)
//        {
//            int a,b;
//            cin>>a>>b;
//            //cout<<pow_mod(a,b,m)<<endl;
//            sum=(sum+pow_mod(a,b,m))%m;
//        }
//        printf("%lld\n",sum);
//    }
//    return 0;
//
//}

//#include<cstdio>
//#include<cstring>
//#include<algorithm>
//using namespace std;
//int main()
//{
//	long long N,i,n,M,c,a,b,sum;
//	scanf("%lld",&N);
//	while(N--)
//	{
//		scanf("%lld%lld",&M,&n);
//		sum=0;
//		for(i=0;i<n;i++)
//		{
//			c=1;
//			scanf("%lld%lld",&a,&b);
//			while(b)
//			{
//				if(b&1)
//				c=c*a%M;
//
//				a=a*a%M;
//				b/=2;
//			}
//			sum=sum+c%M;
//		}
//		printf("%lld\n",sum%M);
//	 }
//	return 0;
//}
