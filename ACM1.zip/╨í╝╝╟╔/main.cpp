//#include <bits/stdc++.h>
////�ҳ����е�������
//using namespace std;
//
//vector<int> primeFactorList;
//
//void getPrimeFactor(int num)
//{
//    for(int i=2;i*i<=num;i++)
//    {
//        if(num%i==0)
//        {
//            primeFactorList.push_back(i);
//            while(num%i==0) num=num/i;
//        }
//    }
//    if(num>1) primeFactorList.push_back(num);
//}
//int main()
//{
//    int x;
//    cin>>x;
//    getPrimeFactor(x);
//    for(int i=0;i<primeFactorList.size();i++)
//        cout<<primeFactorList[i]<<" ";
//    return 0;
//}
