//#include <bits/stdc++.h>
//
//using namespace std;
//typedef long long ll;
//int num[50005];
//ll tree[4*50000 +5];
//
//void build(int p,int l,int r)
//{
//    if(l==r)
//    {
//        tree[p] = num[l];
//        return;
//    }
//    else
//    {
//        int mid = (r+l)>>1;
//        build(p<<1,l,mid);
//        build(p<<1|1,mid+1,r);
//        tree[p] = tree[p<<1] + tree[p<<1|1];
//    }
//}
//
//void add(int p,int l,int r,int ind, int v)
//{
//    if(l==r)
//    {
//        tree[p]+=v;
//        return;
//    }
//    else
//    {
//        int mid = (r+l)>>1;
//        if(ind<=mid) add(p<<1,l,mid,ind,v);
//        else add(p<<1|1,mid+1,r,ind,v);
//        tree[p] = tree[p<<1] + tree[p<<1|1];
//    }
//}
//
//ll query(int p,int l ,int r,int x,int y)
//{
//    if(x<=l && r<=y)
//    {
//        return tree[p];
//    }
//    else
//    {
//        int mid = (l+r)>>1;
//        ll ans = 0;
//        if(x<=mid)
//            ans += query(p<<1,l,mid,x,y);
//        if(mid<y)
//            ans += query(p<<1|1,mid+1,r,x,y);
//        return ans;
//    }
//}
//int main()
//{
//    int t;
//    scanf("%d", &t);
//    for(int i =1;i<=t;i++)
//    {
//        int n;
//        scanf("%d", &n);
//        for(int j =1;j<=n;j++)
//            scanf("%d", &num[j]);
//        build(1,1,n);
//        string s;
//        printf("Case %d:\n", i);
//        while(cin>>s && s[0]!='E')
//        {
//            if(s[0]=='Q')
//            {
//                int x,y;
//                scanf("%d%d", &x, &y);
//                printf("%lld\n", query(1, 1, n, x, y));
//
//            }
//            else if(s[0] == 'A')
//            {
//                int x,y;
//                scanf("%d%d", &x, &y);
//                add(1,1,n,x,y);
//            }
//            else
//            {
//                int x,y;
//                scanf("%d%d", &x, &y);
//                add(1,1,n,x,-y);
//            }
//        }
//    }
//    return 0;
//}
