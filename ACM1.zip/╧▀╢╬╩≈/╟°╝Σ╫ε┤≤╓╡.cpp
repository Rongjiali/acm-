//#include<bits/stdc++.h>
//using namespace std;
//typedef long long ll;
//
//int num[200005];
//ll tree[4 * 200000 + 5];
//
//void build(int p, int l, int r)
//{
//    if(l == r)
//    {
//        tree[p] = num[l];
//        return ;
//    }
//    else
//    {
//        int mid = (r+l) >> 1;
//        build(p<<1, l, mid);
//        build(p<<1|1, mid+1, r);
//        tree[p] = max(tree[p<<1] , tree[p<<1|1]);
//    }
//}
//
//void add(int p, int l, int r, int ind, int v)
//{
//    if(l == r)
//    {
//        tree[p] = v;
//        return ;
//    }
//    else
//    {
//        int mid = (r+l) >> 1;
//        if(ind <= mid) add(p<<1, l, mid, ind, v);
//        else add(p<<1|1, mid+1, r, ind, v);
//        tree[p] = max(tree[p<<1] , tree[p<<1|1]);
//    }
//}
//
//int  query(int p, int l, int r, int x, int y)
//{
//    if(x <= l && r <= y)
//    {
//        return tree[p];
//    }
//    else
//    {
//        int mid = (l+r) >> 1;
//        ll ans1 = 0,ans2 =0;
//        if(x <= mid)
//            ans1= query(p<<1, l, mid, x, y);
//        if(mid < y)
//            ans2= query(p<<1|1, mid+1, r, x, y);
//        return max(ans1,ans2);
//    }
//}
//
//int main(void){
//    int n, m;
//    while(~scanf("%d%d", &n, &m)){
//        for(int j =1;j<=n;j++)
//            scanf("%d", &num[j]);
//        // memset(Max, 0, sizeof(Max));
//        build(1, 1, n);
//        char ch[2];
//        int x, y;
//        while(m--){
//            scanf("%s%d%d", ch, &x, &y);
//            if(ch[0] == 'U') add(1,1,n,x,y);
//            else printf("%d\n", query(1,1,n,x,y));
//        }
//    }
//    return 0;
//}
//
////#include <iostream>
////#include <stdio.h>
////#include <string.h>
////#define lson l, mid, rt << 1
////#define rson mid + 1, r, rt << 1 | 1
////using namespace std;
////
////const int MAXN = 2e5 + 10;
////int Max[MAXN << 2];//Max[rt]�洢rt��Ӧ��������ֵ
////
////void push_up(int rt){//����rt��ֵ
////    Max[rt] = max(Max[rt << 1], Max[rt << 1 | 1]);
////}
////
//////����
////void build(int l, int r, int rt){//rt��Ӧ����[l, r]
////    if(l == r){
////        scanf("%d", &Max[rt]);
////        return;
////    }
////    int mid = (l + r) >> 1;
////    build(lson);
////    build(rson);
////    push_up(rt);//���ϸ���
////}
////
//////�����滻
////void updata(int p, int sc, int l, int r, int rt){//��p��ֵ�滻��sc
////    if(l == r){//�ҵ�p��
////        Max[rt] = sc;
////        return;
////    }
////    int mid = (l + r) >> 1;
////    if(p <= mid) updata(p, sc, lson);
////    else updata(p, sc, rson);
////    push_up(rt);//���ϸ��½ڵ�
////}
////
//////��������ֵ
////int query(int L, int R, int l, int r, int rt){//��ѯ[L, R]�����ֵ
////    if(L <= l && R >= r) return Max[rt];//��ǰ����[l, r]������[L, R]��
////    int cnt = 0;
////    int mid = (l + r) >> 1;
////    if(L <= mid) cnt = max(cnt, query(L, R, lson));//L��mid���
////    if(R > mid) cnt = max(cnt, query(L, R, rson));//R��mid�ұ�
////    return cnt;
////}
////
////int main(void){
////    int n, m;
////    while(~scanf("%d%d", &n, &m)){
////        // memset(Max, 0, sizeof(Max));
////        build(1, n, 1);
////        char ch[2];
////        int x, y;
////        while(m--){
////            scanf("%s%d%d", ch, &x, &y);
////            if(ch[0] == 'U') updata(x, y, 1, n, 1);
////            else printf("%d\n", query(x, y, 1, n, 1));
////        }
////    }
////    return 0;
////}
