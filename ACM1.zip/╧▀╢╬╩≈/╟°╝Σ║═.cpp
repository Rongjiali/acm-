//#include<iostream>
//using namespace std;
//typedef long long ll;
//ll num[100005];
//ll tree[4 * 100000 + 5];
//ll lazy[4 * 100000 + 5]={0};
//int n,m;
//void build(int p, int l, int r)
//{
//    if(l == r)
//        tree[p] = num[l];
//    else
//    {
//        int mid = (l+r) >> 1;
//        build(p<<1, l, mid);
//        build(p<<1|1, mid+1, r);
//        tree[p]  = tree[p<<1] + tree[p<<1|1];
//    }
//}
//
//void pushdown(int p, int l, int r)
//{
//    if(lazy[p])
//    {
//        lazy[p<<1] += lazy[p];
//        lazy[p<<1|1] += lazy[p];
//        tree[p<<1] += lazy[p] * (((l+r)>>1) - l + 1);
//        tree[p<<1|1] += lazy[p] * (r - ((l+r)>>1));
//        lazy[p] = 0;
//    }
//}
//
//void add(int p, int l, int r, int x, int y, ll v)
//{
//    if(x <= l && r <= y)
//    {
//        lazy[p] += v;
//        tree[p] += v * (r-l+1);
//        return ;
//    }
//    else
//    {
//        int mid = (l+r) >> 1;
//        pushdown(p, l, r);
//        if(x <= mid)
//            add(p<<1, l, mid, x, y, v);
//        if(y > mid)
//            add(p<<1|1, mid+1, r, x, y, v);
//        tree[p] = tree[p<<1] + tree[p<<1|1];
//    }
//}
//
//ll query(int p, int l, int r, int x, int y)
//{
//    if(x <= l && r <= y)
//    {
//        return tree[p];
//    }
//    else
//    {
//        int mid = (l+r) >> 1;
//        ll ans = 0;
//        pushdown(p, l, r);
//        if(x <= mid)
//            ans += query(p<<1, l, mid, x, y);
//        if(y > mid)
//            ans += query(p<<1|1, mid+1, r, x, y);
//        return ans;
//    }
//}
//
//int main()
//{
//    cin.sync_with_stdio(false);
//    cin>>n>>m;
//    for(int i=1;i<=n;i++)
//        cin>>num[i];
//    build(1, 1, n);
//    for(int i=1;i<=m;i++)
//    {
//        int  a;
//        cin>>a;
//        if(a == 2)
//        {
//            int x, y;
//            cin>>x>>y;
//            cout<<query(1, 1, n, x, y)<<endl;
//        }
//        else
//        {
//            int x, y;
//            ll c;
//            cin>>x>>y>>c;
//            add(1, 1, n, x, y, c);
//        }
//    }
//    return 0;
//}
