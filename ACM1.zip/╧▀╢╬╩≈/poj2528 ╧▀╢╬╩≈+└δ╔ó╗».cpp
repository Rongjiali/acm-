//#include <iostream>
//#include <cstring>
//#include <cstdio>
//#include <algorithm>
//
//using namespace std;
//
//#define M 10005
//
//int m, li[M], ri[M];
//
//int x[M<<3], col[M<<4], ans;
//bool f[M];
//int Bsearch(int l,int r,int xx)
//{
//    int m;
//    while(l<=r)
//    {
//        m = (l+r)>>1;
//        if(x[m]==xx) return m;
//        else if(x[m]>xx) r = m-1;
//        else l = m+1;
//    }
//    return -1;
//}
//
//void Pushdown(int p)
//{
//    col[p<<1] = col[p<<1|1] = col[p];
//    col[p] = -1;
//}
//void Update(int x,int y,int c,int l ,int r,int rt)
//{
//    if(x<=l && r<=y)
//    {
//        col[rt] = c;
//        return;
//    }
//    if(col[rt]!=-1) Pushdown(rt);
//    int m = (l+r)>>1;
//    if(m>=x) Update(x,y,c,l,m,rt<<1);
//    if(m<y) Update(x,y,c,m+1,r,rt<<1|1);
//}
//void query(int l,int r,int rt)
//{
//    if(l==r)
//    {
//        if(col[rt]!=-1 && !f[col[rt]])
//        {
//            ans++;
//            f[col[rt]] = true;
//        }
//        return ;
//    }
//    if(col[rt]!=-1) Pushdown(rt);
//    int m = (l+r)>>1;
//    query(l,m,rt<<1);
//    query(m+1,r,rt<<1|1);
//}
//
//int main()
//{
//    int t,n,i;
//    cin>>t;
//    while(t--)
//    {
//        memset(col, -1, sizeof (col));
//        memset (f, false, sizeof (f));
//        int num = 0;
//        cin>>n;
//        for(i = 1;i<=n;i++)
//        {
//            cin>>li[i]>>ri[i];
//            x[++num] = li[i];
//            x[++num] = ri[i];
//        }
//        sort(x+1,x+num+1);
//        m = 1;
//        for(i =2;i<=num;i++)
//        {
//            if(x[i]!=x[i-1]) x[++m] = x[i];//ȥ��
//        }
//        for(i = m;i>1;i--)
//        {
//            if(x[i]-x[i-1]>1) x[++m] = x[i]-1;
//        }
//        sort(x+1, x+m+1);
//        for(i =1;i<=n;i++)
//        {
//            int l = Bsearch(1,m,li[i]);
//            int r = Bsearch(1,m,ri[i]);
//            Update(l,r,i,1,m,1);
//        }
//        ans = 0;
//        query(1,m,1);
//        cout<<ans<<endl;
//    }
//    return 0;
//}
