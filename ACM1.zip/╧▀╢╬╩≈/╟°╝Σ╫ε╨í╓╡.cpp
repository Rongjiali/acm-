//#include<bits/stdc++.h>
//using namespace std;
//typedef long long ll;
//
//int num[200005];
//ll tree[4 * 200000 + 5];
//const int MAX = 0x7fffffff;
//void build(int p, int l, int r)
//{
//    if(l == r)
//    {
//        tree[p] = num[l];
//        return ;
//    }
//    else
//    {
//        int mid = (r+l) >> 1;
//        build(p<<1, l, mid);
//        build(p<<1|1, mid+1, r);
//        tree[p] = min(tree[p<<1] , tree[p<<1|1]);
//    }
//}
//
//void add(int p, int l, int r, int ind, int v)
//{
//    if(l == r)
//    {
//        tree[p] = v;
//        return ;
//    }
//    else
//    {
//        int mid = (r+l) >> 1;
//        if(ind <= mid) add(p<<1, l, mid, ind, v);
//        else add(p<<1|1, mid+1, r, ind, v);
//        tree[p] = min(tree[p<<1] , tree[p<<1|1]);
//    }
//}
//
//int  query(int p, int l, int r, int x, int y)
//{
//    if(x <= l && r <= y)
//    {
//        return tree[p];
//    }
//    else
//    {
//        int mid = (l+r) >> 1;
//        ll ans1 = MAX,ans2 =MAX;
//        if(x <= mid)
//            ans1= query(p<<1, l, mid, x, y);
//        if(mid < y)
//            ans2= query(p<<1|1, mid+1, r, x, y);
//        return min(ans1,ans2);
//    }
//}
//
//int main()
//{
//    int n, m;
//    scanf("%d%d",&n,&m);
//    for(int j =1;j<=n;j++)
//        scanf("%d", &num[j]);
//    build(1, 1, n);
//    int x, y;
//    while(m--){
//        cin>>x>>y;
//        cout<<query(1,1,n,x,y)<<" ";
//    }
//
//    return 0;
//}
