#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
//��Ŀ�и���p
int p;
//�ݴ����е�����
long long a[100007];
//�߶����ṹ�壬v��ʾ��ʱ�Ĵ𰸣�mul��ʾ�˷������ϵ�lazytag��add�Ǽӷ������ϵ�
struct node{
    long long v, mul, add;
}tree[400007];
void build(int root,int l,int r)
{
    tree[root].mul =1;
    tree[root].add = 0;
    if(l==r)
        tree[root] .v = a[l];
    else
    {
        int m = (l+r)/2;
        build(root<<1,l,m);
        build(root<<1|1,m+1,r);
        tree[root].v = (tree[root<<1].v+tree[root<<1|1].v);
    }
    tree[root].v%=p;
    return;
}

void pushdown(int root,int l,int r)
{
    int m = (l+r)/2;
    tree[root<<1].v = (tree[root<<1].v * tree[root].mul+tree[root].add*(m-l+1))%p;
    tree[root<<1|1].v = (tree[root<<1|1].v * tree[root].mul+tree[root].add*(r-m))%p;

    tree[root<<1].mul = (tree[root<<1].mul * tree[root].mul)%p;
    tree[root<<1|1].mul = (tree[root<<1|1].mul * tree[root].mul)%p;

    tree[root<<1].add = (tree[root<<1].add * tree[root].mul + tree[root].add)%p;
    tree[root<<1|1].add = (tree[root<<1|1].add * tree[root].mul + tree[root].add)%p;

    tree[root].mul =1 ;
    tree[root].add = 0;
    return ;
}

void up1(int root,int l, int r,int x,int y,ll k)
{
    if(x<=l && r<=y)
    {
        tree[root].v = (tree[root].v * k)%p;
        tree[root].mul = (tree[root].mul*k)%p;
        tree[root].add = (tree[root].add *k)%p;
        return;
    }
    else
    {
        pushdown(root,l,r);
        int m = (l+r)/2;
        if(x<=m)
            up1(root<<1,l,m,x,y,k);
        if(y>m)
            up1(root<<1|1,m+1,r,x,y,k);
        tree[root].v = (tree[root<<1].v+tree[root<<1|1].v)%p;
        return ;
    }
}
void up2(int root,int l, int r,int x,int y,ll k)
{
    if(x<=l && r<=y)
    {
        tree[root].v = (tree[root].v +k*(r-l+1))%p;
        tree[root].add = (tree[root].add +k)%p;
        return;
    }
    else
    {
        pushdown(root,l,r);
        int m = (l+r)/2;
        if(x<=m)
            up2(root<<1,l,m,x,y,k);
        if(y>m)
            up2(root<<1|1,m+1,r,x,y,k);
        tree[root].v = (tree[root<<1].v+tree[root<<1|1].v)%p;
        return ;
    }
}

ll query(int rt,int l,int r,int x,int y)
{
    if(x<=l&&r<=y)
    {
        return tree[rt].v;
    }
    else
    {
        pushdown(rt,l,r);
        int m = (l+r)/2;
        ll ans = 0;
        if(x<=m)
            ans+= query(rt<<1,l,m,x,y);
        if(y>m)
            ans+= query(rt<<1|1,m+1,r,x,y);
        return ans%p;
    }
}
int main()
{
    int n,m;
    cin>>n>>p;
    for(int i=1;i<=n;i++)
        cin>>a[i];
    build(1,1,n);
    cin>>m;
    while(m--)
    {
        int ch;
        cin>>ch;
        int x,y;
        ll k;
        if(ch ==1)
        {
            cin>>x>>y>>k;
            up1(1,1,n,x,y,k);
        }
        else if(ch == 2)
        {
            cin>>x>>y>>k;
            up2(1,1,n,x,y,k);
        }
        else
        {
            cin>>x>>y;
            cout<<query(1,1,n,x,y)<<endl;
        }
    }
    return 0;
}
//#include <iostream>
//#include <cstdio>
//using namespace std;
////��Ŀ�и���p
//int p;
////�ݴ����е�����
//long long a[100007];
////�߶����ṹ�壬v��ʾ��ʱ�Ĵ𰸣�mul��ʾ�˷������ϵ�lazytag��add�Ǽӷ������ϵ�
//struct node{
//    long long v, mul, add;
//}st[400007];
////buildtree
//void bt(int root, int l, int r){
////��ʼ��lazytag
//    st[root].mul=1;
//    st[root].add=0;
//    if(l==r){
//        st[root].v=a[l];
//    }
//    else{
//        int m=(l+r)/2;
//        bt(root*2, l, m);
//        bt(root*2+1, m+1, r);
//        st[root].v=st[root*2].v+st[root*2+1].v;
//    }
//    st[root].v%=p;
//    return ;
//}
////���Ĵ��룬ά��lazytag
//void pushdown(int root, int l, int r){
//    int m=(l+r)/2;
////�������ǹ涨�����ȶȣ����ӵ�ֵ=�˿̶��ӵ�ֵ*�ְֵĳ˷�lazytag+���ӵ����䳤��*�ְֵļӷ�lazytag
//    st[root*2].v=(st[root*2].v*st[root].mul+st[root].add*(m-l+1))%p;
//    st[root*2+1].v=(st[root*2+1].v*st[root].mul+st[root].add*(r-m))%p;
////�ܺ�ά����lazytag
//    st[root*2].mul=(st[root*2].mul*st[root].mul)%p;
//    st[root*2+1].mul=(st[root*2+1].mul*st[root].mul)%p;
//    st[root*2].add=(st[root*2].add*st[root].mul+st[root].add)%p;
//    st[root*2+1].add=(st[root*2+1].add*st[root].mul+st[root].add)%p;
////�Ѹ��ڵ��ֵ��ʼ��
//    st[root].mul=1;
//    st[root].add=0;
//    return ;
//}
////update1���˷���stdl�˿��������ߣ�stdr�˿�������ұߣ�l��������ߣ�r�������ұ�
//void ud1(int root, int l, int r, int x, int y, long long k){
//
//
////����������������������
//    if(x<=l && r<=y){
//        st[root].v=(st[root].v*k)%p;
//        st[root].mul=(st[root].mul*k)%p;
//        st[root].add=(st[root].add*k)%p;
//        return ;
//    }
////�������������ͱ������н���������Ҳ�в�����Ĳ���
////�ȴ���lazytag
//    else
//    {
//        pushdown(root, l, r);
//        int m=(l+r)/2;
//        if(x<=m)
//            ud1(root*2, l, m, x, y, k);
//        if(y>m)
//            ud1(root*2+1, m+1, r, x, y, k);
//        st[root].v=(st[root*2].v+st[root*2+1].v)%p;
//        return ;
//    }
//
//}
////update2���ӷ����ͳ˷�ͬ��
//void ud2(int root, int l, int r, int x, int y, long long k){
//
//    if(x<=l && r<=y){
//        st[root].add=(st[root].add+k)%p;
//        st[root].v=(st[root].v+k*(r-l+1))%p;
//        return ;
//    }
//    else
//    {
//        pushdown(root, l,r);
//        int m=(l+r)/2;
//        if(x<=m)
//            ud2(root*2, l, m, x, y, k);
//        if(y>m)
//            ud2(root*2+1, m+1, r, x, y, k);
//        st[root].v=(st[root*2].v+st[root*2+1].v)%p;
//        return ;
//    }
//
//}
////���ʣ���updateһ��
//long long query(int root, int l, int r, int x, int y){
//    if(x<=l && r<=y){
//        return st[root].v;
//    }
//    else{
//        pushdown(root, l, r);
//        int m=(l+r)/2;
//        long long ans=0;
//        if(x<=m)
//            ans+=query(root*2, l, m, x, y);
//        if(y>m)
//            ans+=query(root*2+1, m+1, r, x, y);
//        return ans%p;
//    }
//
//}
//int main(){
//    int n, m;
//    scanf("%d%d", &n, &p);
//    for(int i=1; i<=n; i++){
//        scanf("%lld", &a[i]);
//    }
//    bt(1, 1, n);
//    scanf("%d", &m);
//    while(m--){
//        int chk;
//        scanf("%d", &chk);
//        int x, y;
//        long long k;
//        if(chk==1){
//            scanf("%d%d%lld", &x, &y, &k);
//            ud1(1, 1, n, x, y, k);
//        }
//        else if(chk==2){
//            scanf("%d%d%lld", &x, &y, &k);
//            ud2(1, 1, n, x, y, k);
//        }
//        else{
//            scanf("%d%d", &x, &y);
//            printf("%lld\n", query(1, 1, n, x, y));
//        }
//    }
//    return 0;
//}
