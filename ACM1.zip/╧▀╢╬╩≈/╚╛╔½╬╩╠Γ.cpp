//#include<iostream>
//using namespace std;
//typedef long long ll;
//ll num[100005];
//int  conow[4*100000 +5] = {0};//��¼��ǰlazy����ɫ
//int  cosum[4*100000 +5] = {0};//��ɫ����
//int n,m;
//void build(int p,int l,int r)
//{
//    if(l==r)
//        cosum[p] =1;
//    else
//    {
//        int mid = (l+r)>>1;
//        build(p<<1,l,mid);
//        build(p<<1|1,mid+1,r);
//        cosum[p] = cosum[p<<1]|cosum[p<<1|1];
//    }
//}
//void pushdown(int p)
//{
//    if(conow[p])
//    {
//        conow[p<<1] = conow[p<<1|1] = conow[p];
//        cosum[p<<1] = cosum[p<<1|1] = cosum[p];
//        conow[p] = 0;
//    }
//}
//
//void update(int p,int l,int r,int x,int y,int c)
//{
//    if(x<=l && r<=y)
//    {
//        conow[p] = 1<<(c-1);
//        cosum[p] = 1<<(c-1);
//        return;
//    }
//    else
//    {
//        int mid = (l+r)>>1;
//        pushdown(p);
//        if(x<=mid)
//            update(p<<1,l,mid,x,y,c);
//        if(y>mid)
//            update(p<<1|1,mid+1,r,x,y,c);
//        cosum[p] = cosum[p<<1]|cosum[p<<1|1];
//
//    }
//}
//
//ll query(int p,int l,int r,int x, int y)
//{
//    if(x<=l && r<=y)
//    {
//        return cosum[p];
//    }
//    else
//    {
//        int mid = (l+r)>>1;
//        ll ans =0;
//        pushdown(p);
//        if(x<=mid)
//            ans |= query(p<<1,l,mid,x,y);
//        if(y>mid)
//            ans |= query(p<<1|1,mid+1,r,x,y);
//        return ans;
//
//    }
//}
//int main()
//{
//    ios::sync_with_stdio(false);
//    int o;
//    while(cin>>n>>o>>m)
//    {
//
//        build(1,1,n);
//        for(int i = 1;i<=m;i++)
//        {
//            char a;
//            cin>>a;
//            if(a=='P')
//            {
//                int x,y;
//                cin>>x>>y;
//                if(x>y) swap(x,y);
//                int t = query(1,1,n,x,y);
//                int ans = 0;
//                 while(t){
//                    if(t&1) ans++;
//                    t>>=1;
//                }
//                cout<<ans<<endl;
//
//            }
//            else
//            {
//                int x,y;
//                int c;
//                cin>>x>>y>>c;
//                if(x>y) swap(x,y);
//                update(1,1,n,x,y,c);
//            }
//        }
//
//    }
//    return 0;
//}
//
//
//
//
//
