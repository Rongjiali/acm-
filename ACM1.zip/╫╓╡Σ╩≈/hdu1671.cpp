#include<bits/stdc++.h>
using namespace std;
const int maxn = 1e5 +10;
int tree[maxn][30]; //�ֵ�������maxn����㣬30��ʾ�ַ����Ĵ�С������Сд��ĸ��26��

int cnt[maxn],isend[maxn];
int tot=0; //�ڵ���

bool insert(char *s)
{
	int root=0, len=strlen(s);
	for(int i=0;i<len;i++)
	{
		int pos = s[i]-'0';
		if(!tree[root][pos])
			tree[root][pos] = ++tot;
		root = tree[root][pos];
		cnt[root]++;
		if(cnt[root]>1 && isend[root])return false;
	}
	isend[root] = 1;
	return (cnt[root]>1&&isend[root]) ? false : true;
}
int main()
{
    int t;
	scanf("%d", &t);
	while(t--)
	{
		int n;
		scanf("%d", &n);
		memset(tree, 0, sizeof(tree));
        memset(cnt, 0, sizeof(cnt));
		memset(isend, 0, sizeof(isend));
		tot = 0;
		int f = 1;
		for(int i=1;i<=n;i++)
		{
			char s[15];
			scanf("%s", s);
			if(!insert(s))f=0;

		}
		if(f)cout<<"YES\n";
		else cout<<"NO\n";
	}
	return 0;
}
