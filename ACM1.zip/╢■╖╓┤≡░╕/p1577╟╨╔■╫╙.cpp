//#include<bits/stdc++.h>
//using namespace std;
//typedef long long ll;
//
//int n,m;
//int  l,r,mid,a[100005];
//int  total ,cnt,ans;
//float b[100005];
//
//bool judge(int x)
//{
//    int num = 0;
//    for(int i = 0;i<n;i++)
//        num+=a[i]/x;
//    return num>=m;
//
//}
//int main()
//{
//    cin>>n>>m;
//    for(int i =0;i<n;i++)
//    {
//        cin>>b[i];
//        a[i] = int(b[i]*100);
//    }
//    int l =0,r = 10000000;
//    while(l<=r)
//    {
//        mid  = (l+r)>>1;
//        if(mid ==0) break;//���ܳ���0
//        if(judge(mid))
//        {
//            l = mid+1;
//            ans = mid;
//        }
//        else
//        {
//            r= mid -1;
//        }
//    }
//    printf("%.2f",ans/100.0);
//}
