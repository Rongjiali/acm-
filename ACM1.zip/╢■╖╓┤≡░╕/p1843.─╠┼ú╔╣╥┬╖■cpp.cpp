//#include<bits/stdc++.h>
//using namespace std;
//typedef long long ll;
//
//int n,d,b;
//int  l,r,mid,a[500005];
//int  total ,cnt,ans;
//
//bool judge(int mid)
//{
//    for(int i=0;i<n;i++)
//    {
//        if((a[i]-mid*d)>0)
//        {
//            if((a[i]-mid*d)%b)
//                cnt = (a[i]-mid*d)/b +1;
//            else
//                cnt= (a[i]-mid*d)/b;
//            total +=cnt;
//        }
//        if(total>mid) return false;
//    }
//    return true;
//}
//int main()
//{
//    cin>>n>>d>>b;
//    l =  r= 0;
//    for(int i = 0;i<n;i++)
//    {
//        cin>>a[i];
//        r= max(r,a[i]);
//    }
//    while(l<=r)
//    {
//        total = cnt = 0;
//        mid = (l+r)>>1;
//        if(judge(mid))
//        {
//            r = mid-1;
//            ans = mid;
//        }
//        else
//        {
//            l= mid +1;
//        }
//    }
//    cout<<ans<<endl;
//    return 0;
//}
