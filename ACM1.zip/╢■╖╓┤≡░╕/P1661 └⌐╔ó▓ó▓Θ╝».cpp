//#include<bits/stdc++.h>
//using namespace std;
//typedef long long ll;
//
//int n;
//int  l,r,mid;
//int  cnt,ans;
//int x[55];
//int y[55];
//int fa[55];//���鼯
//
//int find(int x)
//{
//    if(x!=fa[x])
//    {
//        fa[x] = find(fa[x]);
//    }
//    return fa[x];
//}
//void Union(int x,int y)
//{
//    int r1 = find(x);
//    int r2 = find(y);
//    fa[r1] = r2;
//}
//
//int main()
//{
//    cin>>n;
//    for(int i =1;i<=n;i++)
//    {
//        cin>>x[i]>>y[i];
//    }
//    l = 0;
//    r = 1e9;
//    while(l<=r)
//    {
//        int mid = (l+r)>>1;
//        for(int i = 1;i<=n;i++)
//            fa[i] = i;//��ʼ�����鼯
//        for(int i =1;i<=n;i++)
//            for(int j = i+1;j<=n;j++)
//            {
//                int dis = abs(x[i]-x[j])+abs(y[i]-y[j]);
//                if(dis<=mid*2)
//                {//�����������
//                    Union(i,j);
//                }
//            }
//        cnt = 0;
//        for(int i =1;i<=n;i++)
//            if(fa[i]==i) cnt++;//��ͨ��ĸ���
//
//        if(cnt==1)
//        {
//            r = mid-1;
//            ans = mid;
//        }
//        else l = mid+1;
//    }
//    cout<<ans;
//    return 0;
//}
