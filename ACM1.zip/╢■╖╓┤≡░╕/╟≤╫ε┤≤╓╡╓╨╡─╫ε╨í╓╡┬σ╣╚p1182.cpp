//#include<bits/stdc++.h>
//using namespace std;
//typedef long long ll;
//
//int n,m;
//int  l,r,mid,a[100005];
//int  total ,cnt;
//
//bool judge(int x)
//{
//    for(int i =0;i<n;i++)
//    {
//        if(total+a[i]<=x) total+=a[i];
//        else{
//            total = a[i];//�Ͽ�
//            cnt++;
//        }
//    }
//    return cnt>=m;
//}
//int main()
//{
//    while(cin>>n>>m)
//     {
//        l =r = 0;
//
//        int  ans;
//        for(int i = 0;i<n;i++)
//        {
//            cin>>a[i];
//            r+=a[i];
//            l = max(l,a[i]);
//        }
//        while(l<=r)
//        {
//            mid = (l+r)/2;
//            total = cnt = 0;
//            if(judge(mid)) l = mid+1;//˵��mid̫С��������൫���Ը���
//            else
//            {
//                r = mid -1;  //mid̫�󣬷������
//                ans = mid;
//            }
//        }
//        cout<<ans<<endl;
//     }
//    return 0;
//}
