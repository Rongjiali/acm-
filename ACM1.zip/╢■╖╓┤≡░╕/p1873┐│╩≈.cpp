//#include<bits/stdc++.h>
//using namespace std;
//typedef long long ll;
//
//ll n,m;
//ll  l,r,mid,a[1000005];
//ll  total ,ans;
//
//int main()
//{
//    cin>>n>>m;
//
//    for(int i = 0;i<n;i++) cin>>a[i];
//
//    l = 0;
//    r = 1000000000;
//    while(l<=r)
//    {
//        total = 0;
//        mid = (l+r)/2;
//        for(int i =0;i<n;i++)
//        {
//            if(a[i]>mid)
//            {
//                total+=a[i]-mid;
//            }
//        }
//        if(total<m){
//            r = mid -1;
//        }
//        else{
//            l = mid+1;
//            ans = mid;
//        }
//    }
//    cout<<ans;
//    return 0;
//}
