//#include <bits/stdc++.h>
//using namespace std;
//
//struct node
//{
//    int x,y,z;//zΪȨֵ
//    bool select;
//};
//node  edges[100001];
//
//int fa[10000001];
//
//int find(int x)//���鼯
//{
//    if(x != fa[x])
//    {
//        fa[x] = find(fa[x]);
//    }
//    return fa[x];
//}
//void Union(int x, int y)
//{
//    int r1 = find(x);
//    int r2 = find(y);
//    fa[r1] = r2;
//}
//bool cmp(node a,node b) //С����
//{
//    return a.z < b.z;
//}
//
//struct nodel
//{
//    int to;
//    int next;
//};
//const int maxn = 1001;
//nodel link[maxn];
//int il;
//int head[maxn];
//int end[maxn];
//int length[maxn][maxn];
//
//int  kruskalci(node *edges, int n,int m)
//{
//    int k = 0,ans = 0;
//    int i,x,y;
//    int w,v;
//    //��ʼ���ڽӱ�������ÿһ���ڵ�����һ��ָ���������ıߣ���ʾ��iΪ����Ԫ�ļ���ֻ��i
//    for(il = 0;il<n;il++)
//    {
//        link[il].to = il+1;
//        link[il].next = head[il+1];
//        end[il+1]= il;
//        head[il+1] = il;
//    }
//    cout<<1<<endl;
//    sort(edges+1,edges+m+1,cmp);
//
//    for(i =1;i<=m;i++)
//    {
//        if(k == n-1) break;
//        //if(edges[i].z<0 ) continue;
//        x = find(edges[i].x);
//        y = find(edges[i].y);
//        if(x!=y)
//        {
//            //���������ڵ����ڵļ���
//            for(w=head[x];w!=-1;w=link[w].next)
//            {
//                for(v = head[y];v!=-1;v = link[v].next)
//                {
//                    length[link[w].to][link[v].to] =length[link[v].to][link[w].to] =edges[i].z;
//
//                }
//            }
//            ans += edges[i].z;
//            link[end[y]].next = head[x];
//            end[y] = end[x];
//            Union(x,y);
//            k++;
//            edges[i].select = true;
//        }
//    }
//    return ans;
//}
//int main()
//{
//
//    int i,n,m;
//    cin>>n>>m;
//    for( i = 1;i<=n;i++)
//    {
//        fa[i] = i;
//    }
//    memset(head,-1,sizeof(head));
//    memset(end,-1,sizeof(end));
//    for(i=1;i<=m;i++)
//    {
//        int a,b,c;
//        cin>>a>>b>>c;
//        edges[i].x = a;
//        edges[i].y = b;
//        edges[i].z = c;
//    }
//    int mst,secmst;
//    mst = kruskalci(edges,n,m);
//    cout<<mst<<endl;
//
//
//
//    for(i = 1;i<=m;i++)
//        if(edges[i].select) cout<<i<<" ";
//
//    cout<<endl;
//
//    secmst = INT_MAX;
//    //cout<<1<<" "<<secmst;
//    for(i = 1;i<=m;i++)
//    {
//        if(!edges[i].select)
//        secmst = min(secmst,mst+edges[i].z-length[edges[i].x][edges[i].y]);
//    }
//    cout<<secmst<<endl;
//
//    return 0;
//
//
//
//}
//
////int main() //1550����
////{   //һ����n+1����
////    int n,m = 0,i,j,ans = 0,k = 0,w;
////    cin>>n;
////    for( i = 1;i<=n+1;i++)
////    {
////        fa[i] = i;
////    }
////    for(i = 1;i<=n;i++)//��ˮԴ��n+1����
////    {
////        m++;
////        cin>>w;
////        edges[i].x = i;
////        edges[i].y = n+1;
////        edges[i].z = w;
////    }
////
////    for( i = 1; i <= n; i++)
////    {
////        for( j = 1; j <= n; j++)
////        {
////            cin>>w;
////            if(j>i){
////                m++;
////                edges[m].x = i;
////                edges[m].y = j;
////                edges[m].z = w;
////            }
////        }
////    }
////
////    sort(edges+1,edges+m+1,cmp);
////
////    for(i = 1;i<=m;i++ )
////    {
////
////        if(find(edges[i].x) != find(edges[i].y))
////        {
////
////            ans += edges[i].z;
////            Union(edges[i].x,edges[i].y);
////            k++;
////            if(k == n)
////            {
////                cout<<ans<<endl;
////                return 0;
////            }
////        }
////    }
////
////    return 0;
////}
///*
//6 9
//1 2 1
//1 3 2
//2 3 6
//2 4 11
//3 4 9
//4 6 3
//4 5 7
//3 5 13
//5 6 4
//*/
////int main() //Out of Hay��p1547
////{
////    int n,m,i,ans = 0,k = 0;
////    cin>>n>>m;
////    for( i = 1;i<=n;i++)
////    {
////        fa[i] = i;
////    }
////    for(i=1;i<=m;i++)
////    {
////        int a,b,c;
////        cin>>a>>b>>c;
////        edges[i].x = a;
////        edges[i].y = b;
////        edges[i].z = c;
////    }
////    sort(edges+1,edges+m+1,cmp);
////
////    for(i = 1;i<=m;i++ )
////    {
////        if(find(edges[i].x) != find(edges[i].y))
////        {
////                cout<<"find(edges[i].x)"<<find(edges[i].x)<<"find(edges[i].y)"<<find(edges[i].y)<<endl;
////            ans += edges[i].z;
////            Union(edges[i].x,edges[i].y);
////            k++;
////            if(k == n-1)
////            {
////                cout<<edges[i].z<<endl;
////                return 0;
////            }
////        }
////    }
////
////    return 0;
////}
//
//
////������磬P1546
////int main()
////{
////    int n,i,j,a = 0,w,ans = 0,k = 0;
////    cin>>n;
////    for( i = 1;i<=n;i++)
////    {
////        fa[i] = i;
////    }//��ʼ�����鼯
////    for( i = 1; i <= n; i++)
////    {
////        for( j = 1; j <= n; j++)
////        {
////            cin>>w;
////            if(j>i){
////                a++;
////                edges[a].x = i;
////                edges[a].y = j;
////                edges[a].z = w;
////            }
////        }
////    }
////    sort(edges+1,edges+a+1,cmp);
////
////    for(i = 1;i<=a;i++ )
////    {
////        if(find(edges[i].x) != find(edges[i].y))
////        {
////            ans += edges[i].z;
////            Union(edges[i].x,edges[i].y);
////            k++;
////            if(k == n-1)
////            {
////                cout<<ans;
////                return 0;
////            }
////        }
////    }
////
////    return 0;
////}
