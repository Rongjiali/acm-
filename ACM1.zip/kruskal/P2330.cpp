//#include<bits/stdc++.h>
//using namespace std;
//
//const int maxn = 305;
//const int maxm = 100005;
//
//struct edge
//{
//    int x,y,z;
//};
//edge e[maxm];
//
//int fa[maxn];
//
//bool cmp(edge a,edge b)
//{
//    return a.z<b.z;
//}
//
//int find(int x)//���鼯
//{
//    if(x!=fa[x])
//    {
//        fa[x] = find(fa[x]);
//    }
//    return fa[x];
//}
//void Union(int x,int y)
//{
//    int r1 = find(x);
//    int r2 = find(y);
//    fa[r1] = r2;
//}
//
//int  n,m,ans = 0,k = 0;
//int main()
//{
//    cin>>n>>m;
//    for(int i = 1;i<=n;i++)
//        fa[i] = i;
//    for(int i = 1;i<=m;i++)
//    {
//        int a,b,c;
//        cin>>a>>b>>c;
//        e[i].x =a;
//        e[i].y = b;
//        e[i].z = c;
//    }
//
//    sort(e+1,e+m+1,cmp);
//    for(int i =1;i<=m;i++)
//    {
//        if(find(e[i].x)!=find(e[i].y))
//        {
//            ans+=e[i].z;
//            Union(e[i].x , e[i].y);
//            k++;
//            if(k==n-1)
//            {
//                cout<<k<<" "<<e[i].z;
//                return 0;
//            }
//        }
//    }
//    return 0;
//}
