//#include<bits/stdc++.h>
//
//using namespace std;
//
////dpqiujie
////int n,l,t,ans[10005],maxans;
////int main()
////{
////    scanf("%d",&n);
////    for(int i=1;i<=n;++i){
////        scanf("%d",&i);
////        scanf("%d",&l);
////        int tmp=0;
////        while(scanf("%d",&t)&&t)
////            tmp=max(ans[t],tmp);
////        ans[i]=tmp+l;
////        maxans=max(ans[i],maxans);
////    }
////    printf("%d\n",maxans);
////    return 0;
//// }
//
////
//#define MAXN 10005
//#define MAXM 100005
//int head[MAXN];
//struct EdgeNode
//{
//    int to;
//    int next;
//};
//EdgeNode Edges[MAXM];
//int degree[MAXN] = {0} ;
//
//long long T[MAXN] ;//��Ĵ�С
//bool vis[MAXN]   = {false};
//bool vi[MAXN] = {false};
//int n,m,a,b;
//void  tuopu()
//{   //queue<int> Q;
//    //int x;
//    int iq = 0;
//    int queue[n];
//    for(int i = 1;i<=n;i++)
//    {
//        if(degree[i] == 0 || degree[i] == 1 )
//           {
//               queue[iq++] = i;
//                vi[i] = true;
//           }
//
//    }
//    for(int i = 0;i<iq;i++)
//    {
//        //x = queue[i];
//        //ans = ans>END[x]?ans:END[x];
//        //ɾ���Ӹö��㷢����ȫ������ߣ�����indegree����
//        for(int k = head[queue[i]];k!=-1;k = Edges[k].next)
//        {
//            degree[Edges[k].to]--;
//           // degree[x]--;
//
//            //�����½ڵ㿪ʼʱ��Ϊԭ�����½ڵ㿪ʼʱ����ǰ���ڵ����ʱ��Ľϴ�ֵ
//            //���indegree�����Ϊ0��˵���µ���ǰ�����㱻�ҵ����������
//            if(degree[Edges[k].to] == 0 ||degree[Edges[k].to] == 1 )
//                if(!vi[Edges[k].to])
//                {
//                    queue[iq++] = Edges[k].to;
//                    vi[Edges[k].to] = true;
//                }
//
//        }
//    }
//    for(int i = 0;i<iq;i++)
//        vis[queue[i]] = true;
//
//    long long ans  =0;
//    for(int i = 1;i<=n;i++)
//    {
//        if(!vis[i]) ans+=T[i];
//    }
//    cout<<ans;
//}
//int ecnt;
//void addEdge(int u, int v){
//    Edges[++ecnt].to = v;
//    Edges[ecnt].next = head[u];
//    head[u] = ecnt;
//}
//int main()
//{
//
//    int t;
//    cin>>t;
//
//    while(t--)
//    {
//        memset(head,-1,sizeof(head)) ;
//        memset(degree,0,sizeof(degree)) ;
//        memset(vis,0,sizeof(vis)) ;
//        memset(Edges,-1,sizeof(Edges)) ;
//        memset(vi,0,sizeof(vi)) ;
//
//       // memset(Edges,0,sizeof(Edges));
//        //memset(T,-1,sizeof(head)) ;
//
//        ecnt = 0;
//        cin>>n>>m;
//        for(int i=1;i<=n;i++)
//            cin>>T[i];
//        for(int i =1;i<=m;i++)
//        {
//            cin>>a>>b;
//            addEdge(a,b);
//            addEdge(b,a);
//            degree[a]++;
//            degree[b]++;
//        }
//    tuopu();
//    }
//
//    return 0;
//}
////    cout<<"edge"<<endl;
////    for(int i = 1;i<=b;i++)
////    {
////        cout<<i<<" "<<Edges[i].to<<" "<<endl;
////    }
////    cout<<endl;
////
////    for(int i =1;i<=n;i++)
////    {
////        for(int k = head[i];k!=-1;k=Edges[k].next)
////        {
////            cout<<i<<" "<<Edges[k].to<<" "<<endl;
////        }
////    }
////    cout<<endl;
////    cout<<"head"<<endl;
////    for(int i= 1;i<=n;i++)
////        cout<<head[i]<<" ";
////        cout<<endl;
//
