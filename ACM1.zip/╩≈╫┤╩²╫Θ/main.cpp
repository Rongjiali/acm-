//#include <bits/stdc++.h>
//
//using namespace std;
//const int maxn = 10000000;
//int n;
//int lowbit(int x)
//{
//    return x&(-x);
//}
//
//int tree[maxn],c[maxn];
//
//void update(int x,int y)
//{
//    for(int i = x;i<=n;i+=lowbit(i))
//        tree[i]+=y;
//}
//
//int  getsum(int x)
//{
//    int ans = 0;
//    for(int i=x;i>0;i-=lowbit(i))
//        ans+=tree[i];
//    return ans;
//}
//int main()
//{
//    memset(tree,0,sizeof(tree));
//
//    cin>>n;
//    for(int i =1;i<=n;i++)
//    {
//        cin>>c[i];
//        update(i,c[i]);
//    }
//    int q;
//    while(cin>>q)
//    {
//        cout<<getsum(q)<<endl;
//    }
//    cout << "Hello world!" << endl;
//    return 0;
//}
