//#include<bits/stdc++.h>
//using namespace std;
//
//const int maxn = 500005;
//
//int a[maxn],tree[maxn]={0};
//int n,m;
//int lowbit(int x)
//{
//    return x&(-x);
//}
//
//void update(int x,int y)
//{
//    for(int i =x;i<=n;i+=lowbit(i))
//    {
//        tree[i]+=y;
//    }
//
//}
//int getsum(int x)
//{
//    int ans = 0;
//    for(int i = x;i>0;i-=lowbit(i))
//    {
//        ans+=tree[i];
//    }
//    return ans;
//}
//
//int  main()
//{
//
//    cin>>n>>m;
//    for(int i =1;i<=n;i++)
//    {
//        cin>>a[i];
//        update(i,a[i]);
//    }
//    while(m--)
//    {
//        int c,a,b;
//        cin>>c>>a>>b;
//        if(c==1)
//            update(a,b);
//        else
//        {
//            cout<<getsum(b)-getsum(a-1)<<endl;
//        }
//    }
//    return 0;
//}
