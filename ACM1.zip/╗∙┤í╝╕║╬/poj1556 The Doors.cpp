//#include<iostream>
//#include<cstring>
//#include<algorithm>
//#include<cmath>
//#include<cstdio>
////���⣺10��10�ķ����������ɸ�ǽ�ڣ�ǽ��֮���п�϶����ͨ�������ʴӣ�0,5������10,5�������·��
////
////��������ͼ���߶������ж��Ƿ��ཻ�����ཻ�ͽ��ߡ�Ȼ�������·�������ݽ�С��������·�㷨��
//using namespace std;
//const int maxn = 110;
//const double eps = 1e-8;
//const double inf=0x3f3f3f3f;
//struct point{
//    double x,y;
//    point(){}
//    point(double _x,double _y):x(_x),y(_y){}
//    point operator -(const point &b) const{
//        return point(x-b.x,y-b.y);
//    }
//    double operator ^(const point &b) const{
//        return x*b.y-y*b.x;
//    }
//    double operator *(const point &b) const{
//        return x*b.x+y*b.y;
//    }
//};
//int sgn(double x){
//    if (fabs(x)<eps) return 0;
//    if (x<0) return -1;
//    return 1;
//}
////�󽻵�
//struct line{
//    point s,e;
//    line(){}
//    line(point ss,point ee):s(ss),e(ee){}
//    pair<point,int> operator &(const line &b) const{
//        point res = s;
//        if(sgn((s-e)^(b.s-b.e))==0)
//        {
//            if(sgn((b.s -s)^(b.e-s)) == 0) return make_pair(res,0);//�غ�
//            else return make_pair(res,1);//ƽ��
//        }
//        double k = ((s-b.s)^(b.s - b.e))/((s-e)^(b.s - b.e));
//        res.x += (e.x - s.x) *k;
//        res.y +=(e.y - s.y) *k;
//        return make_pair(res,2);//�ཻ
//    }
//}a[maxn];
//
//double dist(point a,point b){
//     return sqrt((b-a)*(b-a));
// }
//int inter(line l1,line l2){//�ж����߶��Ƿ��ཻ
//    return
//        max(l1.s.x,l1.e.x) >= min(l2.s.x,l2.e.x)
//        && max(l2.s.x,l2.e.x) >= min(l1.s.x,l1.e.x)
//        && max(l1.s.y,l1.e.y) >= min(l2.s.y,l2.e.y)
//        && max(l2.s.y,l2.e.y) >= min(l1.s.y,l1.e.y)
//        && sgn((l2.s-l1.s)^(l1.e-l1.s))*sgn((l2.e-l1.s)^(l1.e-l1.s))<=0
//        && sgn((l1.s-l2.s)^(l2.e-l2.s))*sgn((l1.e-l2.s)^(l2.e-l2.s))<=0;
//}
//double mp[110][110];
//double floyd(int n)
//{
//    for(int i=0;i<=n;i++)
//        for(int j=0;j<=n;j++)
//            for(int k=0;k<=n;k++)
//            if(mp[i][k]+mp[k][j]< mp[i][j]) mp[i][j] = mp[i][k]+mp[k][j];
//    return mp[0][n];
//}
//////int main()
//////{
//////    //point p1,p2;
//////    double a,b,c,d;
//////    cin>>a>>b>>c>>d;
//////    line l1 = line(point(a,b),point(c,d));
//////    cin>>a>>b>>c>>d;
//////    line l2 = line(point(a,b),point(c,d));
//////    if(inter(l1,l2))
//////        cout<<"yes"<<endl;
//////    else cout<<"NO"<<endl;
//////}
//
//int main()
//{
//    int n;double x,y1,y2,y3,y4;
//    while(cin>>n && n!=-1)
//    {
//        for(int i=1;i<=n;i++)
//        {
//            cin>>x>>y1>>y2>>y3>>y4;
//            a[2*i-1]= line(point(x,y1),point(x,y2));
//            a[2*i]= line(point(x,y3),point(x,y4));
//        }
//        for (int i=0;i<=4*n+1;i++)
//              for (int j=0;j<=4*n+1;j++)
//                  if (i==j) mp[i][j]=0;else mp[i][j]=inf;
//        point start = point(0,5);
//        point endd = point(10,5);
//        //����β��ÿ���ŵ�ľ���
//        for(int i=1;i<=4*n;i++)
//        {
//            int l =(i+3)/4; //���ڵ����ӣ�x�ţ�
//            int f=1;
//            point tmp;
//            if(i&1) tmp = a[(i+1)/2].s;
//            else tmp =a[(i+1)/2].e;
//
//            //��i����ǰ������н���������
//            for(int j=1;j<l;j++)
//                if(inter(a[2*j-1],line(start,tmp))==0
//                   &&inter(a[2*j],line(start,tmp))==0) f=0;
//            if(f) mp[0][i] = mp[i][0] = dist(start,tmp);
//            f =1;
//            for (int j=l+1;j<=n;j++)
//                if (inter(a[2*j-1],line(endd,tmp))==0
//                      && inter(a[2*j],line(endd,tmp))==0) f=0;
//            if (f) mp[i][4*n+1]=mp[4*n+1][i]=dist(endd,tmp);
//
//        }
//        //���ŵ�֮��ľ���
//        for(int i=1;i<=4*n;i++)
//        {
//            for(int j=i+1;j<=4*n;j++)
//            {
//                int l1 = (i+3)/4,l2=(j+3)/4;
//                int f =1;
//                point p1,p2;
//                if (i&1) p1=a[(i+1)/2].s; else p1=a[(i+1)/2].e;
//                if (j&1) p2=a[(j+1)/2].s; else p2=a[(j+1)/2].e;
//                //��p1����p2֮�����м�����н��㣬��f=0
//                for(int k=l1+1;k<l2;k++)
//                    if(inter(a[2*k-1],line(p1,p2))==0
//                       && inter(a[2*k],line(p1,p2))==0) f=0;
//                if(f) mp[i][j] = mp[j][i] = dist(p1,p2);
//            }
//        }
//        int f =1;
//        for(int i=1;i<=n;i++)
//            if (inter(a[2*i-1],line(start,endd))==0
//                  && inter(a[2*i],line(start,endd))==0) f=0;
//        if(f) mp[0][4*n+1] = mp[4*n+1][0] =10;
//        double ans = floyd(4*n+1);
//        printf("%.2f\n",ans);
//    }
//}
