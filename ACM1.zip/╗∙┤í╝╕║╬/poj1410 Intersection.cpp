//#include<iostream>
//#include<algorithm>
//#include<cstring>
//#include<cmath>
//typedef long long ll;
//const double eps = 1e-8;
//const int maxn = 10;
//using namespace std;
//int sgn(double x){
//    if (fabs(x)<eps) return 0;
//    if (x<0) return -1;
//    return 1;
//}
//struct point{
//    double x,y;
//    point(){}
//    point(double _x,double _y):x(_x),y(_y){}
//    point operator -(const point &b) const{
//        return point(x-b.x,y-b.y);
//    }
//    double operator ^(const point &b) const{
//        return x*b.y-y*b.x;
//    }
//    double operator *(const point &b) const{
//        return x*b.x+y*b.y;
//    }
//}p[maxn];
//struct line{
//    point s,e;
//    line(){}
//    line(point _s,point _e):s(_s),e(_e){}
//};
//double xmult(point p ,point a,point b)//���
//{
//    return (b-a)^(p-a);
//}
//int inter(line l1,line l2){//�ж����߶��Ƿ��ཻ
//    return
//        max(l1.s.x,l1.e.x) >= min(l2.s.x,l2.e.x)
//        && max(l2.s.x,l2.e.x) >= min(l1.s.x,l1.e.x)
//        && max(l1.s.y,l1.e.y) >= min(l2.s.y,l2.e.y)
//        && max(l2.s.y,l2.e.y) >= min(l1.s.y,l1.e.y)
//        && sgn((l2.s-l1.s)^(l1.e-l1.s))*sgn((l2.e-l1.s)^(l1.e-l1.s))<=0
//        && sgn((l1.s-l2.s)^(l2.e-l2.s))*sgn((l1.e-l2.s)^(l2.e-l2.s))<=0;
//}
//int onseg(point p,line l)//�жϵ�p�Ƿ���l��
//{
//    return
//        sgn(xmult(p,l.s,l.e))==0 &&//���,���� sgn((l.s-p)^(l.e-p))==0 &&
//        sgn(p.x - l.s.x) * (p.x-l.e.x)<=0 &&
//        sgn(p.y - l.s.y) * (p.y - l.e.y)<=0;
//}
//
////�жϵ���͹�������
////���γ�һ��͹�������Ұ���ʱ�����������˳ʱ��������<0��Ϊ>0��
////��ı��:0~n-1
////����ֵ��
////-1:����͹�������
////0:����͹����α߽���
////1:����͹�������
//
//int inConvexPoly(point a,point p[],int n){
//    for (int i=0;i<n;i++){
//        if (sgn((p[i]-a)^(p[(i+1)%n]-a))<0) return -1;
//        else if (onseg(a,line(p[i],p[(i+1)%n]))) return 0;
//    }
//    return 1;
//}
//
//int main()
//{
//    int t;
//    cin>>t;
//    double x1,x2,y2,y1;
//    while(t--)
//    {
//        cin>>x1>>y1>>x2>>y2;
//        line l = line(point(x1,y1),point(x2,y2));
//        cin>>x1>>y1>>x2>>y2;
//        if(x1>x2) swap(x1,x2);
//        if(y1>y2) swap(y1,y2);
//        p[0] = point(x1,y1);
//        p[1] = point(x2,y1);
//        p[2] = point(x2,y2);
//        p[3] = point(x1,y2);
//        // l�;����ཻ
//        if (inter(l,line(p[0],p[1])) || inter(l,line(p[1],p[2]))
//            || inter(l,line(p[2],p[3])) || inter(l,line(p[3],p[0]))){
//                cout << "T\n";continue;
//            }
//        //�ھ�����
//        if(inConvexPoly(l.s,p,4)>=0 || inConvexPoly(l.e,p,4)>=0)
//        {
//            cout<<"T\n";continue;
//        }
//        cout<<"F\n";
//    }
//    return 0;
//}
