//#include<iostream>
//#include<algorithm>
//#include<cstring>
//#include<cmath>
//using namespace std;
//const int dx[10]={0,-1,0,1,-1,0,1,-1,0,1},dy[10]={0,-1,-1,-1,0,0,0,1,1,1};
//const int maxn=1000005;
//typedef long long ll;
//struct point{
//    int x,y;
//    point(){}
//    point(int _x,int _y):x(_x),y(_y){}
//    ll operator ^(const point &b)const{
//        return x*b.y-y*b.x;
//    }
//};
////��һ������ε�������ò�������area/2����������������ϳ�һ���ı��ε����
//struct polygon{
//    int n;
//    point p[maxn];
//    void add(point q){p[n++]=q;}
//    ll getarea(){
//        ll sum=0;
//        for (int i=0;i<n;i++) sum+=(p[i]^(p[(i+1)%n]));
//        return sum<0?-sum:sum;
//    }
//};
//polygon C;
//int main(){
//    char ch;
//    int t,k; cin >> t;
//    while (t--){
//        C.n=0;
//        ll x=0,y=0;
//        while (cin >> ch && ch!='5'){
//            k=ch-'0';
//            x+=dx[k]; y+=dy[k];
//            C.add(point(x,y));
//        }
//        ll ans=C.getarea();
//        if (ans&1) cout << ans/2 << ".5\n";
//        else cout << ans/2 << endl;
//    }
//    return 0;
//}
