//#include<iostream>
//#include<algorithm>
//#include<cstring>
//#include<cmath>
//#include<cstdlib>
//#include<cstdio>
//using namespace std;
//const double eps=1e-8;
//const int maxn=100010;
//
////��Ҫ���Ǳ߽�����
//int sgn(double x){
//    if (fabs(x)<eps) return 0;
//    if (x<0) return -1;
//    return 1;
//}
//struct point{
//    double x,y;
//    point(){}
//    point(double _x,double _y):x(_x),y(_y){}
//    point operator -(const point &b) const{
//        return point(x-b.x,y-b.y);
//    }
//    double operator ^(const point &b) const{
//        return x*b.y-y*b.x;
//    }
//    double operator *(const point &b) const{
//        return x*b.x+y*b.y;
//    }
//};
//struct line{
//    point s,e;
//    line(){}
//    line(point _s,point _e):s(_s),e(_e){}
//}a[maxn];
//double dist(point a,point b){
//    return sqrt((b-a)*(b-a));
//}
////�ж�l1���߶��Ƿ���l2ֱ���ཻ
//int inter(line l1,line l2){
//    return
////        max(l1.s.x,l1.e.x) >= min(l2.s.x,l2.e.x)
////        && max(l2.s.x,l2.e.x) >= min(l1.s.x,l1.e.x)
////        && max(l1.s.y,l1.e.y) >= min(l2.s.y,l2.e.y)
////        && max(l2.s.y,l2.e.y) >= min(l1.s.y,l1.e.y)
//         //sgn((l2.s-l1.s)^(l1.e-l1.s))*sgn((l2.e-l1.s)^(l1.e-l1.s))<=0
//         sgn((l1.s-l2.s)^(l2.e-l2.s))*sgn((l1.e-l2.s)^(l2.e-l2.s))<=0;
//}
//bool vis[maxn];
//int main(){
//
//    int n; double x1,x2,y1,y2;
//    scanf("%d",&n);
//    for (int i=0;i<n;i++){
//        scanf("%lf%lf%lf%lf",&x1,&y1,&x2,&y2);
//        //cin >> x1 >> y1 >> x2 >> y2;
//        a[i]=line(point(x1,y1),point(x2,y2));
//        //vis[i]=1;
//    }
//    int m;
//    scanf("%d",&m);
//
//    for (int i=0;i<m;i++){
//        int ans = 0;
//        scanf("%lf%lf%lf%lf",&x1,&y1,&x2,&y2);
//        line  p = line(point(x1,y1),point(x2,y2));
//        for (int j=0;j<n;j++){
//            if (inter(p,a[j])){ans++;}
//        }
//        //cout<<ans<<endl;
//        if(ans&1) printf("different\n");
//        else printf("same\n");
//    }
//
//
//}
