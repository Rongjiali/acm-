//#include <iostream>
//#include <stdio.h>
//#include <string.h>
//#include <algorithm>
//#include <queue>
//#include <map>
//#include <vector>
//#include <set>
//#include <string>
//#include <math.h>
//
//using namespace std;
//const double eps = 1e-8;
//int sgn(double x)
//{
//    if(fabs(x) < eps)return 0;
//    if(x < 0)return -1;
//    else return 1;
//}
//struct Point
//{
//    double x,y;
//    Point(){}
//    Point(double _x,double _y)
//    {
//        x = _x;y = _y;
//    }
//    Point operator -(const Point &b)const
//    {
//        return Point(x - b.x,y - b.y);
//    }
//    //���
//    double operator ^(const Point &b)const
//    {
//        return x*b.y - y*b.x;
//    }
//    //���
//    double operator *(const Point &b)const
//    {
//        return x*b.x + y*b.y;
//    }
//};
//struct Line
//{
//    Point s,e;
//    Line(){}
//    Line(Point _s,Point _e)
//    {
//        s = _s;e = _e;
//    }
//};
////*�ж��߶��ཻ
//bool inter(Line l1,Line l2)
//{
//    return
//    max(l1.s.x,l1.e.x) >= min(l2.s.x,l2.e.x) &&
//    max(l2.s.x,l2.e.x) >= min(l1.s.x,l1.e.x) &&
//    max(l1.s.y,l1.e.y) >= min(l2.s.y,l2.e.y) &&
//    max(l2.s.y,l2.e.y) >= min(l1.s.y,l1.e.y) &&
//    sgn((l2.s-l1.e)^(l1.s-l1.e))*sgn((l2.e-l1.e)^(l1.s-l1.e)) <= 0 &&
//    sgn((l1.s-l2.e)^(l2.s-l2.e))*sgn((l1.e-l2.e)^(l2.s-l2.e)) <= 0;
//}
//
//struct Node
//{
//    char id;
//    int n;//����
//    Point p[22];
//}node[30];
//bool cmp(Node a,Node b)
//{
//    return a.id < b.id;
//}
//char str[30];
//bool check(Node a,Node b)
//{
//    for(int i = 0;i < a.n;i++)
//        for(int j = 0;j < b.n;j++)
//           if(inter(Line(a.p[i],a.p[(i+1)%a.n]),Line(b.p[j],b.p[(j+1)%b.n])))
//              return true;
//    return false;
//}
//bool ff[30];
//int main()
//{
//    //freopen("in.txt","r",stdin);
//    //freopen("out.txt","w",stdout);
//    int n;
//    while(scanf("%s",str) == 1)
//    {
//        if(str[0] == '.')break;
//        node[0].id = str[0];
//        scanf("%s",str);
//        if(strcmp(str,"square")==0)
//        {
//            node[0].n = 4;
//            scanf(" (%lf,%lf)",&node[0].p[0].x,&node[0].p[0].y);
//            //cout<<node[0].p[0].x<<" "<<node[0].p[0].y<<endl;
//            scanf(" (%lf,%lf)",&node[0].p[2].x,&node[0].p[2].y);
//           // cout<<node[0].p[2].x<<" "<<node[0].p[2].y<<endl;
//            node[0].p[1].x = ((node[0].p[0].x+node[0].p[2].x)+(node[0].p[2].y-node[0].p[0].y))/2;
//            node[0].p[1].y = ((node[0].p[0].y+node[0].p[2].y)+(node[0].p[0].x-node[0].p[2].x))/2;
//            node[0].p[3].x = ((node[0].p[0].x+node[0].p[2].x)-(node[0].p[2].y-node[0].p[0].y))/2;
//            node[0].p[3].y = ((node[0].p[0].y+node[0].p[2].y)-(node[0].p[0].x-node[0].p[2].x))/2;
//        }
//        else if(strcmp(str,"line")==0)
//        {
//            node[0].n = 2;
//            scanf(" (%lf,%lf)",&node[0].p[0].x,&node[0].p[0].y);
//            scanf(" (%lf,%lf)",&node[0].p[1].x,&node[0].p[1].y);
//        }
//        else if(strcmp(str,"triangle")==0)
//        {
//            node[0].n = 3;
//            scanf(" (%lf,%lf)",&node[0].p[0].x,&node[0].p[0].y);
//            scanf(" (%lf,%lf)",&node[0].p[1].x,&node[0].p[1].y);
//            scanf(" (%lf,%lf)",&node[0].p[2].x,&node[0].p[2].y);
//        }
//        else if(strcmp(str,"rectangle")==0)
//        {
//            node[0].n = 4;
//            scanf(" (%lf,%lf)",&node[0].p[0].x,&node[0].p[0].y);
//            scanf(" (%lf,%lf)",&node[0].p[1].x,&node[0].p[1].y);
//            scanf(" (%lf,%lf)",&node[0].p[2].x,&node[0].p[2].y);
//            node[0].p[3].x = node[0].p[2].x + (node[0].p[0].x - node[0].p[1].x);
//            node[0].p[3].y = node[0].p[2].y + (node[0].p[0].y - node[0].p[1].y);
//        }
//        else if(strcmp(str,"polygon")==0)
//        {
//            scanf("%d",&node[0].n);
//            for(int i = 0;i < node[0].n;i++)
//            {
//                scanf(" (%lf,%lf)",&node[0].p[i].x,&node[0].p[i].y);
//            }
//        }
//        n = 1;
//        while(scanf("%s",str)==1)
//        {
//
//            //cout<<str<<endl;
//            if(str[0] == '-')break;
//            node[n].id = str[0];
//            scanf("%s",str);
//            if(strcmp(str,"square")==0)
//            {
//                node[n].n = 4;
//                scanf(" (%lf,%lf)",&node[n].p[0].x,&node[n].p[0].y);
//                scanf(" (%lf,%lf)",&node[n].p[2].x,&node[n].p[2].y);
//                node[n].p[1].x = ((node[n].p[0].x+node[n].p[2].x)+(node[n].p[2].y-node[n].p[0].y))/2;
//                node[n].p[1].y = ((node[n].p[0].y+node[n].p[2].y)+(node[n].p[0].x-node[n].p[2].x))/2;
//                node[n].p[3].x = ((node[n].p[0].x+node[n].p[2].x)-(node[n].p[2].y-node[n].p[0].y))/2;
//                node[n].p[3].y = ((node[n].p[0].y+node[n].p[2].y)-(node[n].p[0].x-node[n].p[2].x))/2;
//            }
//            else if(strcmp(str,"line")==0)
//            {
//                node[n].n = 2;
//                scanf(" (%lf,%lf)",&node[n].p[0].x,&node[n].p[0].y);
//                scanf(" (%lf,%lf)",&node[n].p[1].x,&node[n].p[1].y);
//            }
//            else if(strcmp(str,"triangle")==0)
//            {
//                node[n].n = 3;
//                scanf(" (%lf,%lf)",&node[n].p[0].x,&node[n].p[0].y);
//                scanf(" (%lf,%lf)",&node[n].p[1].x,&node[n].p[1].y);
//                scanf(" (%lf,%lf)",&node[n].p[2].x,&node[n].p[2].y);
//            }
//            else if(strcmp(str,"rectangle")==0)
//            {
//                node[n].n = 4;
//                scanf(" (%lf,%lf)",&node[n].p[0].x,&node[n].p[0].y);
//                scanf(" (%lf,%lf)",&node[n].p[1].x,&node[n].p[1].y);
//                scanf(" (%lf,%lf)",&node[n].p[2].x,&node[n].p[2].y);
//                node[n].p[3].x = node[n].p[2].x + (node[n].p[0].x - node[n].p[1].x);
//                node[n].p[3].y = node[n].p[2].y + (node[n].p[0].y - node[n].p[1].y);
//            }
//            else if(strcmp(str,"polygon")==0)
//            {
//                scanf("%d",&node[n].n);
//                for(int i = 0;i < node[n].n;i++)
//                {
//                    scanf(" (%lf,%lf)",&node[n].p[i].x,&node[n].p[i].y);
//                }
//            }
//            n++;
//        }
//        sort(node,node+n,cmp);
//        for(int i = 0;i < n;i++)
//        {
//            printf("%c ",node[i].id);
//            memset(ff,false,sizeof(ff));
//            int cnt = 0;
//            for(int j = 0;j < n;j++)
//                if(i != j)
//                  if(check(node[i],node[j]))
//                    {
//                        cnt++;
//                        ff[j] = true;
//                    }
//            if(cnt == 0)printf("has no intersections\n");
//            else if(cnt == 1)
//            {
//                printf("intersects with ");
//                for(int j = 0 ; j < n;j++)
//                    if(ff[j])
//                {
//                    printf("%c\n",node[j].id);
//                    break;
//                }
//            }
//            else if(cnt == 2)
//            {
//                printf("intersects with ");
//                for(int j = 0 ; j < n;j++)
//                    if(ff[j])
//                {
//                    if(cnt==2)printf("%c ",node[j].id);
//                    if(cnt==1)printf("and %c\n",node[j].id);
//                    cnt--;
//                }
//            }
//            else
//            {
//                printf("intersects with ");
//                for(int j = 0 ; j < n;j++)
//                    if(ff[j])
//                {
//                    if(cnt > 1)printf("%c, ",node[j].id);
//                    if(cnt==1)printf("and %c\n",node[j].id);
//                    cnt--;
//                }
//            }
//        }
//
//        printf("\n");
//    }
//}
