#include <iostream>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <queue>
#include <map>
#include <vector>
#include <set>
#include <string>
#include <math.h>

using namespace std;
const double eps = 1e-8;
const int maxn = 55;
int n,m,sum,vis[maxn];
struct point{
    double x,y;
    point(){}
    point(double _x,double _y):x(_x),y(_y){}
    point operator -(const point &b) const{
        return point(x-b.x,y-b.y);
    }
    double operator ^(const point &b) const{
        return x*b.y-y*b.x;
    }
    double operator *(const point &b) const{
        return x*b.x+y*b.y;
    }
}p[maxn];

//�󽻵�
struct line{
    point s,e;
    line(){}
    line(point ss,point ee):s(ss),e(ee){}
}s[maxn];
struct circle
{
    double x,y,r;
}c[maxn];

bool in (point po ,circle cir)
{
    return ((po.x - cir.x) * (po.x - cir.x) + (po.y - cir.y) * (po.y - cir.y)) <= (cir.r * cir.r);
}
point GetPoint(line l1 ,point p3  )//�õ�����
{
    point p1 = l1.s;
    point p2 = l1.e;
    point foot;
    double dx = p1.x -p2.x;
    double dy = p1.y -p2.y;
    double u = ((p3.x - p1.x) * dx + (p3.y - p1.y) * dy) / (dx * dx + dy * dy);
    foot.x = p1.x + u * dx;
    foot.y = p1.y + u * dy;
    return foot;
}

bool judge(line seg,circle cir)
{
    if(in(seg.s, cir) || in(seg.e, cir)) return true;///����Բ�ϻ�Բ��
    else
    {
        point p3;
        p3.x = cir.x, p3.y = cir.y;
        point d = GetPoint(seg, p3);
        double X1 = min(seg.s.x, seg.e.x), X2 = max(seg.s.x, seg.e.x);
        double Y1 = min(seg.s.y, seg.e.y), Y2 = max(seg.s.y, seg.e.y);
        double l = (d.x - cir.x) * (d.x - cir.x) + (d.y - cir.y) * (d.y - cir.y);//dist(d,p3);
        if((d.x >= X1 && d.x <= X2) && (d.y >= Y1 && d.y <= Y2) && (l <= (cir.r * cir.r))) return true;
    }
    return false;
}
int main(){
    int t;
    scanf("%d", &t);
    for(int Case = 1; Case <= t; Case++){
        memset(vis, 0, sizeof(vis)), sum = 0;
        memset(p, 0, sizeof(p));
        memset(s, 0, sizeof(s));
        memset(c, 0, sizeof(c));
        scanf("%d%d", &n, &m);
        for(int i = 1; i <= n; i++) scanf("%lf%lf%lf", &c[i].x, &c[i].y, &c[i].r);
        for(int i = 1; i <= m; i++){
            scanf("%lf%lf", &p[i].x, &p[i].y);
            if(i > 1){
                s[i - 1].s.x = p[i - 1].x, s[i - 1].s.y = p[i - 1].y;
                s[i - 1].e.x = p[i].x, s[i - 1].e.y = p[i].y;
            }
        }
        for(int i = 1; i < m; i++){
            for(int j = 1; j <= n; j++){
                if(judge(s[i], c[j])) vis[j]++, sum++;
                ///�ж��߶��Ƿ��Բ�ཻ����Բ��
            }
        }
        if(sum > 0){
            printf("Compound #%d: Reptile triggered these cameras:", Case);
            for(int i = 1; i <= n; i++)
                if(vis[i]) printf(" %d", i);
            printf("\n\n");
        }
        else printf("Compound #%d: Rigid Reptile was undetected\n\n", Case);
    }

    return 0;
}
/*
2
1 4
0 0 5
10 0
10 10
0 10
0 20
*/
