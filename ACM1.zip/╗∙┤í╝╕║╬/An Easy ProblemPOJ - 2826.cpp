//#include<iostream>
//#include<cstring>
//#include<algorithm>
//#include<cmath>
//#include<cstdio>
////��άƽ���ϣ����������߶Σ���ˮ��ֱ���䣬�����������߶���ɵ�������ʢ����ˮ���������
//using namespace std;
//const int maxn = 5010;
//const double eps = 1e-8;
//struct point{
//    double x,y;
//    point(){}
//    point(double _x,double _y):x(_x),y(_y){}
//    point operator -(const point &b) const{
//        return point(x-b.x,y-b.y);
//    }
//    double operator ^(const point &b) const{
//        return x*b.y-y*b.x;
//    }
//    double operator *(const point &b) const{
//        return x*b.x+y*b.y;
//    }
//};
//int sgn(double x){
//    if (fabs(x)<eps) return 0;
//    if (x<0) return -1;
//    return 1;
//}
////�󽻵�
//struct line{
//    point s,e;
//    line(){}
//    line(point ss,point ee):s(ss),e(ee){}
//    pair<point,int> operator &(const line &b) const{
//        point res = s;
//        if(sgn((s-e)^(b.s-b.e))==0)
//        {
//            if(sgn((b.s -s)^(b.e-s)) == 0) return make_pair(res,0);//�غ�
//            else return make_pair(res,1);//ƽ��
//        }
//        double k = ((s-b.s)^(b.s - b.e))/((s-e)^(b.s - b.e));
//        res.x += (e.x - s.x) *k;
//        res.y +=(e.y - s.y) *k;
//        return make_pair(res,2);//�ཻ
//    }
//};
//int inter(line l1,line l2){//�ж����߶��Ƿ��ཻ
//    return
//        max(l1.s.x,l1.e.x) >= min(l2.s.x,l2.e.x)
//        && max(l2.s.x,l2.e.x) >= min(l1.s.x,l1.e.x)
//        && max(l1.s.y,l1.e.y) >= min(l2.s.y,l2.e.y)
//        && max(l2.s.y,l2.e.y) >= min(l1.s.y,l1.e.y)
//        && sgn((l2.s-l1.s)^(l1.e-l1.s))*sgn((l2.e-l1.s)^(l1.e-l1.s))<=0
//        && sgn((l1.s-l2.s)^(l2.e-l2.s))*sgn((l1.e-l2.s)^(l2.e-l2.s))<=0;
//}
//
//
//int main()
//{
//    int x1,x2,x3,x4,y1,y2,y3,y4;
//    int t;
//    line l1,l2;
//    scanf("%d",&t);
//    while(t--)
//    {
//        scanf("%d%d%d%d%d%d%d%d",&x1,&y1,&x2,&y2,&x3,&y3,&x4,&y4);
//        l1 = line(point(x1,y1),point(x2,y2));
//        l2 = line(point(x3,y3),point(x4,y4));
//        if(sgn(l1.s.y - l1.e.y)==0 || sgn(l2.s.y -l2.e.y) ==0)
//        {
//            printf("0.00\n");
//            //cout<<"a";
//            continue;
//        }
//        //��s�Ǹߵ�
//        if(sgn(l1.s.y - l1.e.y)<0) swap(l1.s,l1.e);
//        if(sgn(l2.s.y - l2.e.y)<0) swap(l2.s,l2.e);
//        if(inter(l1,l2) == false)
//        {
//          //  cout<<"b";
//            printf("0.00\n");
//            continue;
//        }
//        if(sgn((l1.s-l1.e)^(l2.s-l2.e)) == 0) // ƽ�л��غ�
//		{
//			printf("0.00\n");
//			continue;
//		}
//        //�ڱ���������
//        if(inter(line(l1.s,point(l1.s.x,100000)),l2) )
//        {
//           // cout<<"c";
//            printf("0.00\n");
//            continue;
//        }
//        //�ڱ����
//        if(inter(line(l2.s,point(l2.s.x,100000)),l1) )
//        {
//            //cout<<"d";
//            printf("0.00\n");
//            continue;
//        }
//        //cout<<"asd";
//        pair<point,int> jd;
//        jd = l1 & l2;
//        point p =jd.first;
//        double ans1;
//        jd = l1 & line(point(100000,l2.s.y),l2.s);
//        point p1 = jd.first;
//        ans1 = fabs((l2.s-p)^(p1-p))/2;
//
//        double ans2;
//        jd = l2 & line(point(100000,l1.s.y),l1.s);
//        point p2 = jd.first;
//        ans2 = fabs((l1.s-p)^(p2-p))/2;
//
//        double ans= min(ans1,ans2);
//
//        printf("%.2f\n",ans);
//    }
//    return 0;
//}
