////���Ǵ�ǰ��һ�ι����Ĺ��ߣ�����Զ�����䵽�ģ�ֻ��ֱ�䡣
////
////
////��Զ���������߿϶���һ���϶˵��һ���¶˵㡣ö�������㣬Ȼ���жϣ��󽻵㡣
////
//
//#include<iostream>
//#include<cstring>
//#include<algorithm>
//#include<cmath>
//#include<cstdio>
////��άƽ���ϣ����������߶Σ���ˮ��ֱ���䣬�����������߶���ɵ�������ʢ����ˮ���������
//using namespace std;
//const int maxn = 5010;
//const double eps = 1e-8;
//struct point{
//    double x,y;
//    point(){}
//    point(double _x,double _y):x(_x),y(_y){}
//    point operator -(const point &b) const{
//        return point(x-b.x,y-b.y);
//    }
//    double operator ^(const point &b) const{
//        return x*b.y-y*b.x;
//    }
//    double operator *(const point &b) const{
//        return x*b.x+y*b.y;
//    }
//};
//int sgn(double x){
//    if (fabs(x)<eps) return 0;
//    if (x<0) return -1;
//    return 1;
//}
////�󽻵�
//struct line{
//    point s,e;
//    line(){}
//    line(point ss,point ee):s(ss),e(ee){}
//    pair<point,int> operator &(const line &b) const{
//        point res = s;
//        if(sgn((s-e)^(b.s-b.e))==0)
//        {
//            if(sgn((b.s -s)^(b.e-s)) == 0) return make_pair(res,0);//�غ�
//            else return make_pair(res,1);//ƽ��
//        }
//        double k = ((s-b.s)^(b.s - b.e))/((s-e)^(b.s - b.e));
//        res.x += (e.x - s.x) *k;
//        res.y +=(e.y - s.y) *k;
//        return make_pair(res,2);//�ཻ
//    }
//};
//
////�ж�ֱ�ߺ��߶��ཻ
//bool Seg_inter_line(line l1,line l2) //�ж�ֱ��l1���߶�l2�Ƿ��ཻ
//{
//    return sgn((l2.s-l1.e)^(l1.s-l1.e))*sgn((l2.e-l1.e)^(l1.s-l1.e)) <= 0;
//}
//
//point up[100],down[100];
//
//int main()
//{
//    int n;
//    while(scanf("%d",&n),n)
//    {
//        for(int i=0;i<n;i++)
//        {
//            scanf("%lf%lf",&up[i].x,&up[i].y);
//            down[i].x = up[i].x;
//            down[i].y = up[i].y-1;
//        }
//        bool flag = false;//��������
//        double ans = -10000000.0;
//        int k;
//        for(int i=0;i<n;i++)
//        {
//            for(int j=i+1;j<n;j++)
//            {
//                //������
//                for(k=0;k<n;k++)//�ж��ܷ�ȫ������
//                    if(Seg_inter_line(line(up[i],down[j]),line(up[k],down[k]))== false)
//                        break;
//                if(k>=n)
//                {
//                    flag = true;
//                    break;
//                }
//                //����
//                if(k>max(i,j))
//                {
//                    if(Seg_inter_line(line(up[i],down[j]),line(up[k-1],up[k])))
//                    {
//                        pair<point,int> jd = line(up[i],down[j]) & line(up[k-1],up[k]);
//                        point p = jd.first;
//                        ans = max(ans,p.x);
//                    }
//                    if(Seg_inter_line(line(up[i],down[j]),line(down[k-1],down[k])))
//                    {
//                        pair<point,int> jd = line(up[i],down[j]) & line(down[k-1],down[k]);
//                        point p = jd.first;
//                        ans = max(ans,p.x);
//                    }
//                }
//                //������
//                for(k=0;k<n;k++)//�ж��ܷ�ȫ������
//                    if(Seg_inter_line(line(down[i],up[j]),line(up[k],down[k]))== false)
//                        break;
//                if(k>=n)
//                {
//                    flag = true;
//                    break;
//                }
//                //����
//                if(k>max(i,j))
//                {
//                    if(Seg_inter_line(line(down[i],up[j]),line(up[k-1],up[k])))
//                    {
//                        pair<point,int> jd = line(down[i],up[j]) & line(up[k-1],up[k]);
//                        point p = jd.first;
//                        ans = max(ans,p.x);
//                    }
//                    if(Seg_inter_line(line(down[i],up[j]),line(down[k-1],down[k])))
//                    {
//                        pair<point,int> jd = line(down[i],up[j]) & line(down[k-1],down[k]);
//                        point p = jd.first;
//                        ans = max(ans,p.x);
//                    }
//                }
//                if(flag) break;
//            }
//        }
//        if(flag)printf("Through all the pipe.\n");
//        else printf("%.2f\n",ans);
//    }
//}
//
//
