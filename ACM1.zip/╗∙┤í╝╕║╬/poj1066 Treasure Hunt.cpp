//#include<iostream>
//#include<algorithm>
//#include<cstring>
//#include<cmath>
//typedef long long ll;
//const double eps = 1e-8;
//const int maxn = 50;
//using namespace std;
//const double dx[]={0,0,100,100},dy[]={0,100,0,100};
//int sgn(double x){
//    if (fabs(x)<eps) return 0;
//    if (x<0) return -1;
//    return 1;
//}
//struct point{
//    double x,y;
//    point(){}
//    point(double _x,double _y):x(_x),y(_y){}
//    point operator -(const point &b) const{
//        return point(x-b.x,y-b.y);
//    }
//    double operator ^(const point &b) const{
//        return x*b.y-y*b.x;
//    }
//    double operator *(const point &b) const{
//        return x*b.x+y*b.y;
//    }
//}p[2*maxn];
//struct line{
//    point s,e;
//    line(){}
//    line(point _s,point _e):s(_s),e(_e){}
//}a[maxn];
//double xmult(point p ,point a,point b)//���
//{
//    return (b-a)^(p-a);
//}
//int inter(line l1,line l2){//�ж����߶��Ƿ��ཻ
//    return
//        max(l1.s.x,l1.e.x) >= min(l2.s.x,l2.e.x)
//        && max(l2.s.x,l2.e.x) >= min(l1.s.x,l1.e.x)
//        && max(l1.s.y,l1.e.y) >= min(l2.s.y,l2.e.y)
//        && max(l2.s.y,l2.e.y) >= min(l1.s.y,l1.e.y)
//        && sgn((l2.s-l1.s)^(l1.e-l1.s))*sgn((l2.e-l1.s)^(l1.e-l1.s))<=0
//        && sgn((l1.s-l2.s)^(l2.e-l2.s))*sgn((l1.e-l2.s)^(l2.e-l2.s))<=0;
//}
//
//int main()
//{
//    int n;
//    double x1,x2,y2,y1;
//    while(cin>>n)
//    {
//        for(int i=1;i<=n;i++)
//        {
//            cin>>x1>>y1>>x2>>y2;
//            a[i] = line(point(x1,y1),point(x2,y2));
//            p[2*i -1] = point(x1,y1);
//            p[2*i]  = point(x2,y2);
//        }
//        point s;
//        cin>>x1>>y1;
//        s = point (x1,y1);
//        int ans = 99999;
//        //ǽ�ϵĵ�
//        for(int i=1;i<= 2*n;i++)
//        {
//            line l1=line(s,p[i]);
//            int res = 0;
//            for(int j=1;j<=n;j++)
//                if(inter(l1,a[j])) res++;
//            ans = min(ans,res);
//        }
//        //ǽ�Ľǵĵ�
//        for(int i=0;i<4;i++)
//        {
//            line l1 = line(s,point(dx[i],dy[i]));
//            int res = 0;
//            for(int j=1;j<=n;j++)
//                if(inter(l1,a[j])) res++;
//            ans = min(ans,res+1);
//        }
//        cout << "Number of doors = " << ans << endl;
//    }
//}
