//#include<iostream>
//#include<cstring>
//#include<algorithm>
//#include<cmath>
//#include<cstdio>
////���⣺��������ֱ�ߣ�������ֱ�ߵ�λ�ù�ϵ��ƽ�У��غϣ��ཻ�����ཻ�Ļ�������㡣
//using namespace std;
//const int maxn = 5010;
//const double eps = 1e-8;
//struct point{
//    double x,y;
//    point(){}
//    point(double _x,double _y):x(_x),y(_y){}
//    point operator -(const point &b) const{
//        return point(x-b.x,y-b.y);
//    }
//    double operator ^(const point &b) const{
//        return x*b.y-y*b.x;
//    }
//    double operator *(const point &b) const{
//        return x*b.x+y*b.y;
//    }
//};
//int sgn(double x){
//    if (fabs(x)<eps) return 0;
//    if (x<0) return -1;
//    return 1;
//}
////�󽻵�
//struct line{
//    point s,t;
//    line(){}
//    line(point ss,point ee):s(ss),t(ee){}
//    pair<point,int> operator &(const line &b) const{
//        point res = s;
//        if(sgn((s-t)^(b.s-b.t))==0)
//        {
//            if(sgn((b.s -s)^(b.t-s)) == 0) return make_pair(res,0);//�غ�
//            else return make_pair(res,1);//ƽ��
//        }
//        double k = ((s-b.s)^(b.s - b.t))/((s-t)^(b.s - b.t));
//        res.x += (t.x - s.x) *k;
//        res.y +=(t.y - s.y) *k;
//        return make_pair(res,2);//�ཻ
//    }
//}box[maxn];
//
//int main()
//{
//    int n;
//    cin>>n;
//    double x1,x2,y1,y2;
//    line l1,l2;
//    cout << "INTERSECTING LINES OUTPUT\n";
//    for(int i=0;i<n;i++)
//    {
//        cin>>x1>>y1>>x2>>y2;
//        l1 = line(point(x1,y1),point(x2,y2));
//        cin>>x1>>y1>>x2>>y2;
//        l2 = line(point(x1,y1),point(x2,y2));
//        pair<point ,int> ans = l1&l2;
//        if (ans.second==2) printf("POINT %.2f %.2f\n",ans.first.x,ans.first.y);
//        else if (ans.second==1) printf("NONE\n");
//        else printf("LINE\n");
//    }
//    cout << "END OF OUTPUT\n";
//         return 0;
//}
