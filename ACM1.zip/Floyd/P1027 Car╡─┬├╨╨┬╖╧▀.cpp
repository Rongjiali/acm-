#include<bits/stdc++.h>
using namespace std;

struct data{
    int x,y;
    int city;//���ڳ���
    double T;//�����ڵĻ���
};

const int maxn =100;

int s,t,A,B;
data a[(maxn<<2)+10];
int T[maxn+10];
double cost[maxn+10][maxn+10];

int square(int x) {return x*x;}

double dist(int x1,int y1,int x2,int y2)
{
    return sqrt(square(x1-x2)+square(y1-y2));
}

void get_4th(int x1,int y1,int x2,int y2,int x3,int y3,int i)
{
    int ab = square(x1-x2)+square(y1-y2);
    int ac=square(x1-x3)+square(y1-y3);
    int bc=square(x2-x3)+square(y2-y3);

    int x4,y4;
    if (ab+ac==bc) x4=x2+x3-x1, y4=y2+y3-y1;
    if (ab+bc==ac) x4=x1+x3-x2, y4=y1+y3-y2;
    if (ac+bc==ab) x4=x1+x2-x3, y4=y1+y2-y3;

    a[i+3].x = x4;
    a[i+3].y = y4;
}
void init()
{
    memset(a,0,sizeof(a));
    memset(cost,0x3f,sizeof(cost));
    cin>>s>>t>>A>>B;
    for(int i =1;i<=4*s;i+=4)
    {
        double TT;
        cin>>a[i].x>>a[i].y>>a[i+1].x>>a[i+1].y>>a[i+2].x>>a[i+2].y;
        cin>>TT;
        a[i].city = a[i+1].city = a[i+2].city =a[i+3].city= i/4+1;
        a[i].T = a[i+1].T = a[i+2].T =a[i+3].T= TT;
        get_4th(a[i].x,a[i].y,a[i+1].x,a[i+1].y,a[i+2].x,a[i+2].y,i);
        //cout<<a[i+3].x<<" "<<a[i+3].y<<" ";
    }

    for(int i=1;i<=4*s;i++)
    {
        for(int j =1;j<=4*s;j++)
        {
            if(i==j)
                continue;
            data p1=a[i],p2 = a[j];
            double dis = dist(p1.x,p1.y,p2.x,p2.y),w=0.0;
            if(p1.city==p2.city)
                w= dis* p1.T;
            else
                w=dis * t;
            cost[i][j] = cost[j][i] =w;
        }
    }
}

void solve()
{
    for(int k = 1;k<=4*s;k++)
    for(int i = 1;i<=4*s;i++)
    for(int j = 1;j<=4*s;j++)
        cost[i][j] = min(cost[i][j],cost[i][k]+cost[k][j]);

    double min_v = 0x7fffffff;

    int Aid = 4*(A-1)+1,Bid = 4*(B-1)+1;
    for(int i = Aid;i<=Aid+3;i++)
        for(int j = Bid;j<=Bid+3;j++)
            min_v = min(min_v,cost[i][j]);
     cout << std::fixed << std::setprecision(1) << min_v << endl;
}

int main()
{
    int n;
    cin>>n;
    while(n--)
    {
        init();
        solve();
    }
    return 0;
}
