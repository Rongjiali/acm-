//#include <bits/stdc++.h>
//
//using namespace std;
//
//int dp[105][105];
//int main()
//{
//    int n,m;
//    cin>>n>>m;
//    int i;
//    for(i = 1;i<=m;i++)
//    {
//        int x,y,z;
//        cin>>x>>y>>z;
//        dp[x][y] =z;
//    }
//    for(int k = 1;k<=n+1;k++)
//    for( i = 1;i<=n+1;i++)
//    for(int j =1;j<=n+1;j++)
//    {
//         if(dp[i][k]&&dp[k][j])
//            if(dp[i][j]<dp[i][k]+dp[k][j])
//            dp[i][j]=dp[i][k]+dp[k][j];
//    }
//    //cout<<1<<" ";
//    cout<<dp[1][n+1]<<endl;
//    cout<<1<<" ";
//    for( i = 2;i<=n+1;i++)
//        if(dp[1][i]+dp[i][n+1]==dp[1][n+1])
//        cout<<i<<" ";
//    return 0;
//}
//
