//#include <bits/stdc++.h>
//
//using namespace std;
//
//const int maxn = 110;
//int dp[maxn][maxn];
//#define INF 0x3f3f3f3f
//int n,s,e;//��������㣬�յ�
//void solve()
//{
//      memset(dp,INF,sizeof(dp));
//
//    for(int i = 1; i <= n; i++)//�Լ����Լ����ð�����
//    {
//        dp[i][i] = 0;
//    }
//    cin>>n>>s>>e;
//
//    int num,k;
//    for(int i= 1;i<=n;i++)//����
//    {
//        cin>>num;
//        for(int j = 1;j<=num;j++)
//        {
//            cin>>k;
//            if(j == 1) dp[i][k] = 0;
//            else dp[i][k] = 1;
//
//        }
//    }
//    for(k = 1;k<=n;k++)
//    for(int i = 1;i<=n;i++)
//    for(int j =1;j<=n;j++)
//    {
//        //if(!(i == j || i == k || j == k))
//            if(dp[i][j]>dp[i][k]+dp[k][j])
//            dp[i][j]=dp[i][k]+dp[k][j];
//    }
//
//}
//
//
//int main()
//{
//    //memset(dp,INT_MAX,sizeof(dp));
//        for(int i = 1;i<maxn;i++)
//       for(int j = 1;j<maxn;j++)
//        dp[i][j] = INT_MAX;
//    cout<<INT_MAX<<" "<<dp[2][3]<<endl;
////    solve();
////    if(dp[s][e]==INF)
////        cout<<-1<<endl;
////    else cout<<dp[s][e]<<endl;
//    return 0;
//}
