//#include <bits/stdc++.h>
//#define INF 0x3f3f3f3f
//using namespace std;
//
//const int maxn = 205;
//int dp[maxn][maxn];
//int a[maxn];//�ؽ����ʱ��
//int N,M;
//void floyd(int k)
//{
//    for(int i = 0;i<N;i++)
//    for(int j =0;j<N;j++)
//    {
//        //if(!(i == j || i == k || j == k))
//            if(dp[i][j]>dp[i][k]+dp[k][j])
//            dp[i][j]=dp[i][k]+dp[k][j];//˫�����
//            dp[j][i] = dp[i][j];
//    }
//}
//int main()
//{
//
//    cin>>N>>M;
//    int i,c,b,d;
//    memset(dp,INF,sizeof(dp));
//    for( i =0;i<N;i++)//�ؽ����ʱ��
//    {
//        cin>>a[i];
//    }
//    for( i = 0;i<M;i++)
//    {
//        cin>>c>>b>>d;
//        dp[c][b] = dp[b][c] = d;//˫���
//    }
//    for( i = 0; i < N; i++)
//    {
//        dp[i][i] = 0;
//    }
//    int Q;//ѯ��
//    cin>>Q;
//    int now = 0;
//    for(i=0;i<Q;i++)
//    {
//        int s1,s2,s3;
//        cin>>s1>>s2>>s3;
//        while(a[now] <= s3 && now<N)
//        {
//            floyd(now);
//            now++;
//        }
//        if(a[s1]>s3 ||a[s2]>s3)
//            cout<<-1<<endl;
//        else if(dp[s1][s2] == INF) cout<<-1<<endl;
//            else cout<<dp[s1][s2]<<endl;
//    }
//    return 0;
//}
