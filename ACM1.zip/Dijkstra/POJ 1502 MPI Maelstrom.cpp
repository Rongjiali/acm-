//#include <cstdio>
//#include <cstring>
//#include <cstdlib>
//#include <cmath>
//#include <string>
//#include <iostream>
//#include <stack>
//#include <queue>
//#include <vector>
//#include <algorithm>
//#define mem(a,b) memset(a,b,sizeof(a))
//#define N 100+20
//#define M 100000+20
//#define inf 0x3f3f3f3f
//using namespace std;
//int map[N][N],dis[N],vis[N];
//int n;
//
//void dj(int s)
//{
//    int k ,minn;
//    for(int i=1;i<=n;i++)
//    {
//        dis[i] = map[s][i];
//        vis[i] =0;
//    }
//    for(int i=1;i<=n;i++)
//    {
//        k = 0;minn = inf;
//        for(int j =1;j<=n;j++)
//            if(!vis[j] && dis[j]<minn)
//            {
//                minn = dis[j];
//                k = j;
//            }
//        vis[k] =1;
//        for(int j=1;j<=n;j++)
//            if(!vis[j])
//                dis[j] = min(dis[j],dis[k]+map[k][j]);
//    }
//}
//
//int main()
//{
//
//    while(~scanf("%d",&n))
//    {
//        int maxx = 0;
//        char s[10];
//        mem(map,inf);
//        mem(vis,0);
//        mem(dis,0);
//        for(int i=2;i<=n;i++)
//            for(int j=1;j<i;j++)
//            {
//                scanf("%s",s);
//                if(strcmp(s,"x")==0)
//                    map[i][j] = map[j][i] = inf;
//                else
//                    map[i][j] = map[j][i] = atoi(s);
//            }
//        for(int i=1;i<=n;i++)
//            map[i][i] = 0;
//        dj(1);
//        for(int i=1; i<=n; i++)
//            if(dis[i]>maxx)
//                maxx=dis[i];//���������·���ҳ�����
//        printf("%d\n",maxx);
//
//    }
//}
//
//
