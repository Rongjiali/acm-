////
////#include<stdio.h>
////#include<string.h>
////#include<algorithm>
////#include<queue>
////using namespace std;
////#define inf 0x3f3f3f3f
////#define mx 200
////int n,A,B;
////int e[mx][mx];
////
////void folyd()
////{
////    for(int k=1;k<=n;k++)
////        for(int i=1;i<=n;i++)
////            for(int j=1;j<=n;j++)
////                e[i][j]=min(e[i][j],e[i][k]+e[k][j]);
////}
////
////int main()
////{
////    scanf("%d%d%d",&n,&A,&B);
////    for(int i=1;i<=n;i++)
////        for(int j=1;j<=n;j++)
////        e[i][j] = i==j? 0 :inf;
////    for(int i=1;i<=n;i++)
////    {
////        int k,v;
////        scanf("%d",&k);
////        for(int j=1;j<=k;j++)
////        {
////            scanf("%d",&v);
////            e[i][v] = j==1? 0:1;
////        }
////    }
////    folyd();
////    if(e[A][B]==inf)
////        printf("-1\n");
////    else
////        printf("%d\n",e[A][B]);
////    return 0;
////
////}
//#include<stdio.h>
//#include<string.h>
//#include<algorithm>
//#include<iostream>
//#include<queue>
//using namespace std;
//#define inf 0x3f3f3f3f
//const int maxn = 500;
//const int maxm = 1500;
//
//
//
//int dis[maxn],vis[maxn],head[maxm];
//struct node
//{
//    int to;
//    int w;
//    int next;
//};
//node edge[maxm];
//int cnt1 = 1;
//void Addedge(int u,int v,int w)//˫��洢
//{
//    edge[cnt1].to = v;
//    edge[cnt1].w = w;
//    edge[cnt1].next = head[u];
//    head[u] = cnt1;
//    cnt1++;
//}
//
//bool SPFA(int s, int n)
//{
//    int i,k;
//    queue<int> q;
//    int top;
//    int outque[maxn];//��¼���ӵĴ�����ĳ������ӳ���N-1�Σ�����ڸ���
//    for(i = 0;i<=n;i++)
//    {
//        dis[i] = inf;
//    }
//    memset(vis,0,sizeof(vis));
//    memset(outque,0,sizeof(outque));
//
//
//    q.push(s);
//    dis[s] = 0;
//    vis[s] = true;//��һ��������ӣ����б��
//    while(!q.empty())
//    {
//        top = q.front();
//        q.pop();
//        vis[top] = 0;
//        outque[top]++;
//        if(outque[top]>n) return false;
//        for(k = head[top];k!=-1;k = edge[k].next)
//        {
//            int v = edge[k].to;
//            if(dis[v]>(dis[top]+edge[k].w))
//            {
//                dis[v]=dis[top]+edge[k].w;
//                //��¼���·��������Ū��ǰ��pre[v] = top
//                if(vis[v]==0)//δ��������
//                {
//                    vis[v] =1;
//                    q.push(v);
//                }
//            }
//        }
//    }
//    return true;
//}
//int main()
//{
//    int m,s,e;
//    cin>>m>>s>>e;
//    memset(head,-1,sizeof(head));
//    for(int i =1;i<=m;i++)
//    {
//        int k;
//        cin>>k;
//        for(int j=0;j<k;j++)
//        {
//            int to;
//            cin>>to;
//            if(j)
//                Addedge(i,to,1);
//            else
//                Addedge(i,to,0);
//        }
//
//    }
//    //
//    SPFA(s,m);
//    if(dis[e]==inf)
//        cout<<-1<<endl;
//    else cout<<dis[e]<<endl;
//    return 0;
//}
