////��Ŀ���⣺
////��n���˷��ǹ���m������a��b��c����˼��a��b�ٵ��ǹ��������Բ�����c����Ҳ����d(b)-d(a) < c����1��n�ٵ��ǹ��������ֵ��
//#include<stdio.h>
//#include<string.h>
//#include<algorithm>
//#include<iostream>
//#include<queue>
//#include<math.h>
//const int MaxN = 30010, MaxM = 150010;
//const int inf = 0x3f3f3f3f;
//using namespace std;
//struct node
//{
//    int to;
//    int w;
//    int next;
//};
//node edge[MaxM];
//int head[MaxN],dis[MaxN],cnt1=1;
//bool vis[MaxN];
//int n,m;
//void Addedge(int u,int v,int w)//˫��洢
//{
//    edge[cnt1].to = v;
//    edge[cnt1].w = w;
//    edge[cnt1].next = head[u];
//    head[u] = cnt1;
//    cnt1++;
//}
//
//struct node1//�ѽ��
//{
//    int dis;//Դ�㵽pos�ľ���
//    int pos;
//    bool operator<(const node1 &x) const
//    {
//        return x.dis<dis;
//    }
//};
//std::priority_queue<node1> q;
//void dijkstra(int s)//���
//{
//    dis[s] = 0;
//    q.push( ( node1 ){0, s} );
//    while(!q.empty())
//    {
//        node1 tmp = q.top();
//        q.pop();
//        int x = tmp.pos;//d = tmp.dis;
//        if(vis[x])
//            continue;
//        vis[x] =1;
//        for(int i = head[x];i!=-1;i = edge[i].next)
//        {
//            int y = edge[i].to;
//            if(dis[y]>dis[x] + edge[i].w)
//            {
//                dis[y] = dis[x] + edge[i].w;
//                if(!vis[y])
//                {
//                    q.push((node1){dis[y],y});
//                }
//            }
//        }
//
//
//    }
//}
//
//int main()
//{
//    memset(head,-1,sizeof(head));
//    memset(dis,inf,sizeof(dis));
//    memset(vis,false,sizeof(vis));
//    scanf("%d%d",&n,&m);
//    for(int i=1;i<=m;i++)
//    {
//        int u,v,w;//v-u��=w
//        scanf("%d%d%d", &u, &v, &w);
//        Addedge(u,v,w);
//    }
//    dijkstra(1);
//    printf("%d\n",dis[n]);
//    return 0;
//}
