//#include<bits/stdc++.h>
//
//const int MaxN = 1000005, MaxM = 4000005;//�ٶ�Ӹ�0�ͱ���
//
//using namespace std;
//struct node
//{
//    int to;
//    //int w;
//    int next;
//};
//node edge[MaxM];
//int head[MaxN],dis[MaxN],ans[MaxN],cnt1=1;
//bool vis[MaxN];
//
//void Addedge(int u,int v)//˫��洢
//{
//    edge[cnt1].to = v;
//    edge[cnt1].next = head[u];
//    head[u] = cnt1;
//    cnt1++;
//}
////bool SPFA(int s, int n)
////{
////    int i,k;
////    queue<int> q;
////    int top;
////    //int outque[MaxN];//��¼���ӵĴ�����ĳ������ӳ���N-1�Σ�����ڸ���
////
////    for(i = 0;i<=n;i++)
////    {
////        dis[i] = INT_MAX;
////    }
////
////    memset(vis,0,sizeof(vis));
////   // memset(outque,0,sizeof(outque));
////    memset(ans,0,sizeof(ans));
////    ans[s] = 1;
////
////
////    q.push(s);
////    dis[s] = 0;
////    vis[s] = true;//��һ��������ӣ����б��
////    while(!q.empty())
////    {
////        top = q.front();
////        q.pop();
////        vis[top] = 0;
////        //outque[top]++;
////        //if(outque[top]>n) return false;
////        for(k = head[top];k!=-1;k = edge[k].next)
////        {
////            int v = edge[k].to;
////            if(dis[v]>(dis[top]+1))
////            {
////                dis[v] = dis[top]+1;
////                ans[v] = ans[top];
////                if(vis[v]==0)//δ��������
////                {
////                    vis[v] =1;
////                    q.push(v);
////                }
////            }
////            else if(dis[v]==dis[top]+1 )
////            {
////                ans[v] += ans[top];
////                ans[v] %= 100003;
////            }
////        }
////    }
////    return true;
////}
//struct node1//�ѽ��
//{
//    int dis;//Դ�㵽pos�ľ���
//    int pos;
//    bool operator<(const node1 &x) const
//    {
//        return x.dis<dis;
//    }
//};
//std::priority_queue<node1> q;
//void dijkstra(int s,int n)//���
//{
//    for(int i = 0;i<=n;i++)
//    {
//        dis[i] = INT_MAX;
//    }
//   // memset(vis,0,sizeof(vis));
//    //memset(ans,0,sizeof(ans));
//    ans[s] = 1;
//    dis[s] = 0;
//    q.push( ( node1 ){0, s} );
//    while(!q.empty())
//    {
//        node1 tmp = q.top();
//        q.pop();
//        int x = tmp.pos;//d = tmp.dis;
//        if(vis[x])
//            continue;
//        vis[x] =1;
//        for(int i = head[x];i!=-1;i = edge[i].next)
//        {
//            int y = edge[i].to;
//            if(dis[y]>dis[x] + 1)
//            {
//                dis[y] = dis[x] + 1;
//                ans[y] = ans[x];
//                if(!vis[y])
//                {
//                    q.push((node1){dis[y],y});
//                }
//            }
//            else if(dis[y]==dis[x] + 1)
//            {
//                ans[y] += ans[x];
//                ans[y] %= 100003;
//            }
//        }
//
//
//    }
//}
//
//int main()
//{
//    int n,m,a,b;
//    cin>>n>>m;
//    memset(head,-1,sizeof(head));
//    for(int i=1;i<=m;i++)
//    {
//        cin>>a>>b;
//        Addedge(a,b);
//        Addedge(b,a);//˫��洢��
//    }
//    dijkstra(1,n);
//    for(int i=1; i<=n; i++)
//        cout<<ans[i]<<endl;
//    return 0 ;
////    if(SPFA(1,n))
////    {
////        for(int i=1; i<=n; i++)
////        cout<<ans[i]<<endl;
////    }
////    else cout<<"wrong"<<endl;
//}
