//#include <cstdio>
//#include <cstring>
//#include <string>
//#include <iostream>
//#include <stack>
//#include <queue>
//#include <vector>
//#include <cmath>
//#include <algorithm>
//#define mem(a,b) memset(a,b,sizeof(a))
//#define maxnum 300
//#define inf 0x3f3f3f3f
////������֮������ͨ·���е����ߵ���Сֵ
//using namespace std;
//int x[maxnum],y[maxnum],n;
//double mp[maxnum][maxnum];
//double dis[maxnum];
//int vis[maxnum];
//void dj(int s)
//{
//    mem(vis,0);
//    for(int i=1; i<=n; i++)
//        dis[i]=inf;//������ñ���memset
//    dis[s]=0;
//    for(int i=1; i<=n; i++)
//    {
//        int minn=inf,k;
//        for(int j=1; j<=n; j++)
//            if(vis[j]==0&&dis[j]<minn)
//            {
//                k=j;
//                minn=dis[j];
//            }
//        vis[k]=1;
//        for(int j=1; j<=n; j++)
//            dis[j]=min(dis[j],max(dis[k],mp[k][j]));//dis[j]Ϊ��һ��ʯͷ����j��ʯͷ����ͨ·������е���С�ߣ�Ҫ���������max
//    }
//}
//int main()
//{
//    int q=1;
//    while(~scanf("%d",&n)&&n)
//    {
//        mem(mp,0);
//        for(int i=1; i<=n; i++)
//            scanf("%d%d",&x[i],&y[i]);
//        for(int i=1; i<=n; i++)
//            for(int j=i+1; j<=n; j++)
//                mp[i][j]=mp[j][i]=sqrt(double(x[i]-x[j])*(x[i]-x[j])+double(y[i]-y[j])*(y[i]-y[j]));
//        dj(1);
//        printf("Scenario #%d\nFrog Distance = %.3f\n\n",q++,dis[2]);
//    }
//    return 0;
//}
//////floyd
////#include <cstdio>
////#include <cstring>
////#include <string>
////#include <iostream>
////#include <stack>
////#include <queue>
////#include <vector>
////#include <cmath>
////#include <algorithm>
////#define mem(a,b) memset(a,b,sizeof(a))
////#define maxnum 300
////#define inf 0x3f3f3f3f
////using namespace std;
////int x[maxnum],y[maxnum],n;
////double map[maxnum][maxnum];
////void floyd()
////{
////    for(int k=1; k<=n; k++)
////        for(int i=1; i<=n; i++)
////            for(int j=1; j<=n; j++)
////                map[i][j]=min(map[i][j],max(map[i][k],map[k][j]));//����ͨ·������е���С��
////}
////int main()
////{
////    int q=1;
////    while(~scanf("%d",&n)&&n)
////    {
////        mem(map,0);
////        for(int i=1; i<=n; i++)
////            scanf("%d%d",&x[i],&y[i]);
////        for(int i=1; i<=n; i++)
////            for(int j=i+1; j<=n; j++)
////                map[i][j]=map[j][i]=sqrt(double(x[i]-x[j])*(x[i]-x[j])+double(y[i]-y[j])*(y[i]-y[j]));
////        floyd();
////        printf("Scenario #%d\nFrog Distance = %.3f\n\n",q++,map[1][2]);
////    }
////    return 0;
////}
//
////spfa
////#include <cstdio>
////#include <cstring>
////#include <string>
////#include <iostream>
////#include <stack>
////#include <queue>
////#include <vector>
////#include <cmath>
////#include <algorithm>
////#define mem(a,b) memset(a,b,sizeof(a))
////#define maxnum 300
////#define inf 0x3f3f3f3f
////using namespace std;
////int x[maxnum],y[maxnum],n;
////double map[maxnum][maxnum];
////double dis[maxnum];
////int vis[maxnum];
////void spfa()
////{
////    queue<int>q;
////    for(int i=1; i<=n; i++)
////        dis[i]=inf;
////    dis[1]=0;
////    for(int i=1; i<=n; i++)
////        vis[i]=0;
////    vis[1]=1;
////    q.push(1);
////    while(!q.empty())
////    {
////        int k=q.front();
////        vis[k]=0;
////        q.pop();
////        for(int j=1; j<=n; j++)
////            if(max(dis[k],map[k][j])<dis[j])
////            {
////                dis[j]=max(dis[k],map[k][j]);
////                if(vis[j]==0)
////                {
////                    q.push(j);
////                    vis[j]=1;
////                }
////            }
////    }
////}
////int main()
////{
////    int q=1;
////    while(~scanf("%d",&n)&&n)
////    {
////        mem(map,0);
////        for(int i=1; i<=n; i++)
////            scanf("%d%d",&x[i],&y[i]);
////        for(int i=1; i<=n; i++)
////            for(int j=i+1; j<=n; j++)
////                map[i][j]=map[j][i]=sqrt(double(x[i]-x[j])*(x[i]-x[j])+double(y[i]-y[j])*(y[i]-y[j]));
////        spfa();
////        printf("Scenario #%d\nFrog Distance = %.3f\n\n",q++,dis[2]);
////    }
////    return 0;
////}
