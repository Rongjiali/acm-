////���⣺�һ����ʣ����һ�ֻ���ͨ���н������ܻ��ĸ��ߵı������ң����Yes,�������No!
////
////˼·��flyod�㷨���ӶȻ����е�߰�����������⻹�ǿ��Թ���
//
//#include<stdio.h>
//#include<string.h>
//#include<iostream>
//#include<algorithm>
//#include<math.h>
//#include<queue>
//using namespace std;
//
//const int maxn = 505;
//const int inf = 0x3f3f3f3f;
//
//double maps[maxn][maxn];
//int n,m;
//void init()
//{
//    for (int i = 1; i <= n; i++)
//		for (int j = 1; j <= n; j++)
//			maps[i][j] = i==j?1.0:inf;
//}
//int   floyd()
//{
//    for(int k=1;k<=n;k++)
//        for(int i =1;i<=n;i++)
//        {
//            for(int j=1;j<=n;j++)
//            {
//                if(maps[i][j]<(maps[i][k]*maps[k][j]))
//                    maps[i][j] = maps[i][k]*maps[k][j];
//            }
//            if(maps[i][i]>1.0)
//                return 1;
//        }
//    return 0;
//}
//
//int main()
//{
//
//
//    ios::sync_with_stdio(false);
//    string s[maxn];
//    int t=1;
//    while(cin>>n&&n!=0)
//    {
//        init();
//        for(int i=1;i<=n;i++)
//            cin>>s[i];
//        cin>>m;
//        double c;
//        string a,b;
//        int x,y;
//        for(int i=1;i<=m;i++)
//        {
//            cin>>a>>c>>b;
//            for(int j=1;j<=n;j++)
//                if(a==s[j])
//                {
//                    x = j;
//                    break;
//                }
//            for(int j=1;j<=n;j++)
//                if(b==s[j])
//                {
//                    y = j;
//                    break;
//                }
//            maps[x][y] = c;
//        }
//        if(floyd()) printf("Case %d: Yes\n",t++);
//        else    printf("Case %d: No\n",t++);
//    }
//}
