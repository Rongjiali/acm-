///https://blog.csdn.net/qq_37495823/article/details/81240501
# include <iostream>
# include <stdio.h>
# include <algorithm>
# include <queue>
using namespace std;
# define LL long long
# define MAXN 310///��ǵ�������Ŀ
# define MAX 0x3f3f3f3f
LL data[MAXN][MAXN];///��¼���������ֵ��������֮��ߵ�Ȩֵ
LL dis[MAXN];///��¼���㵽ʼ������·
int N;
LL SPFA(int start, int end)
{
    queue<int>Q;
    bool flag[MAXN];///��ǵ��Ƿ����ڶ�����
    for(int i=1;i<=N;i++)
    {
        if(i==start)
        {
            dis[i]=MAX;
            flag[i]=false;
        }
        else
        {
            Q.push(i);
            dis[i]=data[start][i];
            flag[i]=true;
        }
    }
    while(!Q.empty())
    {
        int t=Q.front();
        Q.pop();
        flag[t]=false;
        for(int i=1;i<=N;i++)
        {
            if(dis[i]>dis[t]+data[t][i])
            {
                dis[i]=dis[t]+data[t][i];
                if(!flag[i])
                {
                    Q.push(i);
                    flag[i]=true;
                }
            }
        }
    }
    return dis[N];
}
int main()
{
    while(cin>>N)
    {
        for(int i=1;i<=N;i++)
        {
            for(int j=1;j<=N;j++)
                scanf("%I64d",&data[i][j]);
        }
        SPFA(1,N);
        LL a=dis[N];
        LL b=dis[1];
        SPFA(N,N);
        LL c=dis[N];
        cout<<min(a,b+c)<<endl;
    }
    return 0;
}
