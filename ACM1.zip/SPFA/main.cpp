//#include <bits/stdc++.h>
//using namespace std;
//
//const int maxn=10005;
//const int maxm=500005;
//int dis[maxn],vis[maxn],head[maxm];
//struct node
//{
//    int to;
//    int w;
//    int next;
//};
//node edge[maxm];
//int cnt1 = 1;
//void Addedge(int u,int v,int w)//˫��洢
//{
//    edge[cnt1].to = v;
//    edge[cnt1].w = w;
//    edge[cnt1].next = head[u];
//    head[u] = cnt1;
//    cnt1++;
//}
//
//bool SPFA(int s, int n)
//{
//    int i,k;
//    queue<int> q;
//    int top;
//    int outque[maxn];//��¼���ӵĴ�����ĳ������ӳ���N-1�Σ�����ڸ���
//    for(i = 0;i<=n;i++)
//    {
//        dis[i] = INT_MAX;
//    }
//    memset(vis,0,sizeof(vis));
//    memset(outque,0,sizeof(outque));
//
//
//    q.push(s);
//    dis[s] = 0;
//    vis[s] = true;//��һ��������ӣ����б��
//    while(!q.empty())
//    {
//        top = q.front();
//        q.pop();
//        vis[top] = 0;
//        outque[top]++;
//        if(outque[top]>n) return false;
//        for(k = head[top];k!=-1;k = edge[k].next)
//        {
//            int v = edge[k].to;
//            if(dis[v]>(dis[top]+edge[k].w))
//            {
//                dis[v]=dis[top]+edge[k].w;
//                //��¼���·��������Ū��ǰ��pre[v] = top
//                if(vis[v]==0)//δ��������
//                {
//                    vis[v] =1;
//                    q.push(v);
//                }
//            }
//        }
//    }
//    return true;
//}
//int main()
//{
//    int n,m,s;
//    cin>>n>>m>>s;
//    memset(head,-1,sizeof(head));
//    for(int i =1;i<=m;i++)
//    {
//        int a,b,c;
//        cin>>a>>b>>c;
//        Addedge(a,b,c);
//    }
//    //
//    if(SPFA(s,n))
//    {
//        for(int i=1; i<=n; i++)
//        if(s==i) cout<<0<<" "; //����ǻص��Լ���ֱ�����0
//        else cout<<dis[i]<<" "; //�����ӡ��̾���
//    }
//    else cout<<"wrong"<<endl;
//    return 0;
//}
