//#include <stdio.h>
//#include <iostream>
//#include<string>
//#include<string.h>
//#include<algorithm>
//#include<math.h>
//#define maxx 100000+10
//using namespace std;
//int nex[maxx];
//void getnext(const char *s)
//{
//    int slen = strlen(s);
//	int i = 0, j = -1;
//	nex[0] = -1;
//	while(i != slen)
//	{
//		if(j == -1 || s[i] == s[j])
//			nex[++i] = ++j;
//		else
//			j = nex[j];
//	}
//}
//
//int main()
//{
//    char s1[maxx], s2[maxx];
//    while (scanf("%s%s", s1, s2) != EOF)
//    {
//        int s1len = strlen(s1);
//        int s2len = strlen(s2);
//        strcat(s1, s2);//s1 = s1+s2;
////        cout<<s1<<endl;
//        getnext(s1);
//        int ans = nex[strlen(s1)];
//        while (ans > s1len || ans > s2len)
//        {
//            ans = nex[ans];
//        }
//        if (ans == 0 || ans == -1)
//        {
//            printf("0\n");
//        }
//        else
//        {
//            s1[ans] = 0;
//            printf("%s %d\n", s1, ans);
//        }
//    }
//
//    return 0;
//}
