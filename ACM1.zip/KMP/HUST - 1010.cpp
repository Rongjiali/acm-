//#include<iostream>
//#include<cstring>
//#include<cstdio>
//#include<algorithm>
//using namespace std;
//#define N 1000111
////next��������
//char s[N];
//int nextval[N];
//int len;
//
//void getnext(const char *s)
//{
//	int i = 0, j = -1;
//	nextval[0] = -1;
//	while(i != len)
//	{
//		if(j == -1 || s[i] == s[j])
//			nextval[++i] = ++j;
//		else
//			j = nextval[j];
//	}
//}
//
//int main()
//{
//    while(~scanf("%s",&s))
//    {
//        len = strlen(s);
//        getnext(s);
//        printf("%d\n",len-nextval[len]);
//    }
//}
