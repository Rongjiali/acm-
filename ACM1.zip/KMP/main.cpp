//#include <bits/stdc++.h>
//using namespace std;
//
//int nxt[1000010];
//void getnext(string p)//�ǰ׺��׺
//{
//    int plen = p.length();
//    nxt[0] = -1;
//    int k =-1;
//    int j =0;
//    while(j<=plen -1)
//    {
//        if(k==-1 || p[j]==p[k])
//        {
//            ++k;
//            ++j;
//            nxt[j] = k;
//        }
//        else
//        {
//            k = nxt[k];
//        }
//    }
//}
////void getnxt2(string p)
////{
////    int plen = p.length();
////    nxt[0] = 0;
////    int j=0;
////    for(int i=1;i<plen;i++)
////    {
////        while(j&&p[i]!=p[j+1])
////            j = nxt[j];
////        if(p[j+1]==p[i]) j++;
////        nxt[i] = j;
////    }
////}
//void getnextval(string p)//�Ż�����next
//{
//    int plen = p.length();
//    nxt[0] =-1;
//    int k =-1;
//    int j = 0;
//    while(j<plen-1)
//    {
//        if(k==-1 || p[j]==p[k])
//        {
//            ++j;
//            ++k;
//            if(p[j]!=p[k])
//                nxt[j]=k;
//            else
//                nxt[j] = nxt[k];
//        }
//        else
//        {
//             k = nxt[k];
//        }
//    }
//}
//
//int KMP(string s,string p)
//{
//    int j=0;
//    int i = 0;
//    int slen = s.length();
//    int plen = p.length();
//    while(i<slen && j<plen)
//    {
//        if(j==-1 || s[i]==p[j])
//        {
//            i++;
//            j++;
//        }
//        else
//            j = nxt[j];
//    }
//    if(j==plen)
//        return i-j;
//    else
//        return -1;
//}
//void KMP2(string s,string p)//�ҳ�ÿһ��
//{
//    int j=0;
//    int i = 0;
//    int slen = s.length();
//    int plen = p.length();
//    while(i<slen )
//    {
//        if(j==-1 || s[i]==p[j])
//        {
//            i++;
//            j++;
//        }
//        else
//            j = nxt[j];
//        if(j==plen)
//        {
//            cout<<i-j+1<<endl;
//            j = nxt[j];
//            i--;
//        }
//    }
//    for(int i=1;i<=plen;i++)
//        cout<<nxt[i]<<" ";
//
//}
//int main()
//{
//    string s,p;
//    cin>>s>>p;
//    //cout<<s<<" "<<p<<endl;
//    getnext(p);
//    KMP2(s,p);
//
//    return 0;
//}
