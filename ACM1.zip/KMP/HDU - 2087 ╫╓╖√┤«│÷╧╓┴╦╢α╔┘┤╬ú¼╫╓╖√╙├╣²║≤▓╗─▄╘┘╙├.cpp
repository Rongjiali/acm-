//#include <stdio.h>
//#include <string.h>
//#include <bits/stdc++.h>
//using namespace std;
//
//int next1[10005];
//char str1[1000005],str2[10005];
//int cnt;
//
//void get_next(int len2)//����next����
//{
//    int i = 0,j = -1;
//    next1[0] = -1;
//    while (i<len2)
//    {
//        if(j == -1 || str2[i] == str2[j])
//        {
//            i++;
//            j++;
//            if (str2[i]!=str2[j])
//                next1[i] = j;
//            else
//                next1[i] = next1[j];
//        }
//        else
//            j = next1[j];
//    }
////    for(int i=0;i<=len2;i++)
////        cout<<next1[i]<<endl;
//
//}
//
//int kmp(int len1,int len2)//kmp�㷨
//{
//    int i=0,j=0;
//    get_next(len2);
//    while(i<len1)
//    {
//        if(j==-1||str1[i]==str2[j])
//        {
//            ++i;
//            ++j;
//        }
//        else
//            j=next1[j];
//        if(j == len2)
//        {
//            cnt++;
//            //j = next1[j];
//            j=0;
//        }
//    }
//}
//
//int main()
//{
//
//    int len1,len2;
//    while(scanf("%s",&str1)!=EOF )
//    {
//        if(str1[0]=='#')
//            break;
//        scanf("%s",&str2);
//        len1 = strlen(str1);
//        len2 = strlen(str2);
//        cnt = 0;
//        kmp(len1,len2);
//        printf("%d\n",cnt);
//    }
//    return 0;
//}
//
