//#include<iostream>
//#include<cstring>
//#include<cstdio>
//#include<algorithm>
//using namespace std;
//#define N 1000005
////next��������
//char s[N];
//int nextval[N];
//int len;
//
//void getnext(const char *s)
//{
//	int i = 0, j = -1;
//	nextval[0] = -1;
//	while(i != len)
//	{
//		if(j == -1 || s[i] == s[j])
//			nextval[++i] = ++j;
//		else
//			j = nextval[j];
//	}
//}
//
//int main()
//{
//    while(scanf("%s",&s))
//    {
//        if(strcmp(s,".") == 0) {
//            break;
//        }
//        int ans=1;
//        len = strlen(s);
//        getnext(s);
////        for(int i = 0; i <= len; ++i) //�鿴next���������
////			cout<<nextval[i]<<" ";
////		cout<<endl;
//        int xunhunlen = len-nextval[len];
//        if(len%xunhunlen==0)
//        {
//            ans = len/xunhunlen;
//        }
//        printf("%d\n",ans);
//    }
//}
