//#include<iostream>
//#include<cstring>
//#include<cstdio>
//#include<algorithm>
//
//using namespace std;
//#define N 400010
////next��������
//char s[N];
//int nextval[N];
//int ans[N];
//int len;
//
//void getnext(const char *s)
//{
//	int i = 0, j = -1;
//	nextval[0] = -1;
//	while(i != len)
//	{
//		if(j == -1 || s[i] == s[j])
//			nextval[++i] = ++j;
//		else
//			j = nextval[j];
//	}
//}
//
//int main()
//{
//    while(scanf("%s",&s)!=EOF)
//    {
//
//        len = strlen(s);
//        getnext(s);
//        for(int i = 0; i <= len; ++i) //�鿴next���������
//			cout<<nextval[i]<<" ";
//		cout<<endl;
//        int t;
//        int cnt=0;
//        t = len;
//        while(t)
//        {
//            ans[cnt++]=t;
//            t=nextval[t];
//        }
//        for(int i=cnt-1;i>=0;i--)
//            printf("%d ",ans[i]);
//        printf("\n");
//    }
//}
