//#include <bits/stdc++.h>
//using namespace std;
//const int maxn = 10005;
//int nxt[1000010];
//int M[maxn],N[maxn];
//int lenM,lenN;
//void getnextval()
//{
//    nxt[0] =-1;
//    int k =-1;
//    int j = 0;
//    while(j<lenN-1)
//    {
//        if(k==-1 || N[j]==N[k])
//        {
//            ++j;
//            ++k;
//            if(N[j]!=N[k])
//                nxt[j]=k;
//            else
//                nxt[j] = nxt[k];
//        }
//        else
//        {
//             k = nxt[k];
//        }
//    }
//}
//
//int KMP()
//{
//    int j=0;
//    int i = 0;
//    while(i<lenM && j<lenN)
//    {
//        if(j==-1 || M[i]==N[j])
//        {
//            i++;
//            j++;
//        }
//        else
//            j = nxt[j];
//    }
//    if(j==lenN)
//        return i-j;
//    else
//        return -2;
//}
//
//int main()
//{
//    int t;
//    scanf("%d",&t);
//    while(t--)
//    {
//        scanf("%d%d",&lenM,&lenN);
//        for(int i=0;i<lenM;i++)
//            scanf("%d",&M[i]);
//        for(int i=0;i<lenN;i++)
//            scanf("%d",&N[i]);
//        //cout<<s<<" "<<p<<endl;
//        getnextval();
//        printf("%d\n",KMP()+1);
//
//    }
//
//    return 0;
//}
