#include <iostream>
#include <bits/stdc++.h>
using namespace std;

#define n 4
#define m 10
//int n = 10, m = 20;
int head[n];

struct EdgeNode
{
    EdgeNode()
    {
        to = w = next  = -1;
    }
    int to;
    int w;
    int next;
};
EdgeNode Edges[m];



int ans[20];
int ansi = 0;
bool visit[2*n];
bool s [n] = {0};



void DFS(int now)
{
    int k;
    for(k = head[now];k!=-1;k=Edges[k].next)
    {
        if(!visit[k])
        {
            visit[k] =true;//��ǵ�ǰ��
            visit[k^1] =true;//,��Ƿ����һ����

            DFS(Edges[k].to);
            ans[ansi++] = k^1;//���ݹ����м�¼��
        }
    }
}

void DFS1(int now)//����������
{
    int k;
    for(k = head[now];k!=-1;k=Edges[k].next)
    {
        if(!visit[k])
        {
            visit[k] =true;//��ǵ�ǰ��
            //visit[k^1] =true;//��Ƿ����һ����

            DFS1(Edges[k].to);

        }
    }
    ans[ansi++] = now;//���ݹ����м�¼��
}

void DFST(int x)
{
    visit[x] = true;
    cout<<x<<" ";
    int i;
    for(i = head[x];i!=-1;i = Edges[i].next)
    {
        if(!visit[Edges[i].to])
            DFST(Edges[i].to);
    }
}
void BFS(int x)
{
    int queue[n];
    int iq = 0;
    queue[iq++] = x;
    s[x] = true;
    int i,k;
    for(i = 0;i<iq;i++)
    {
        cout<<queue[i]<<" ";
        for(k = head[queue[i]];k!=-1;k = Edges[k].next)
        {
            if(!s[Edges[k].to])
            {
                queue[iq++] = Edges[k].to;
                s[Edges[k].to] = true;
            }
        }
    }
}
/*
0 1 1
1 0 1
0 3 1
3 0 1
1 2 1
2 1 1
2 3 1
3 2 1
3 4 1
4 3 1
3 5 1
5 3 1
4 5 1
5 4 1
*/
/*
0 1 1
0 2 1
1 3 1
2 4 1
2 5 1
3 5 1
4 6 1
5 6 1
5 7 1
6 7 1
*/
int indegree[n] = {0} ;

void tuopu()
{
    int iq = 0;
    int queue[n];
    for(int i = 0;i<n;i++)
    {
        if(indegree[i] == 0)
            queue[iq++] = i;
    }
    for(int i = 0;i<iq;i++)
    {   //ɾ���Ӹö��㷢����ȫ������ߣ�����indegree����
        for(int k = head[queue[i]];k!=-1;k = Edges[k].next)
        {
            indegree[Edges[k].to]--;
            //���indegree�����Ϊ0��˵���µ���ǰ�����㱻�ҵ����������
            if(indegree[Edges[k].to] == 0)
                queue[iq++] = Edges[k].to;
        }
    }
    for(int i  = 0;i<iq ;i++) cout<<queue[i]<<" ";
    cout<<endl;
}
int main()
{

    for(int i = 0;i<n;i++)
    {
        cout<<s[i]<<" ";
    }
    int o = 6;
   // cout<<o^1<<" "<<o<<endl;
   int p = o^1;
    cout<<p<<""<<o<<endl;
    memset(head,-1,sizeof(head)) ;
    //cout<<head[0]<<head[2]<<head[6]<<endl;
    memset(ans,-1,sizeof(ans)) ;
    memset(visit,false,sizeof(visit));

    cout<<"����������ͱ���"<<endl;
    int numv,nume,i,j,w;
    cin>>numv>>nume;
    int k;
    //head[7] =-1;
    cout<<"head[7]: "<<head[7]<<endl;
    for(k =0;k<nume;k++)
    {
        cin>>i>>j>>w;
        indegree[j]++;
        Edges[k].to = j;
        Edges[k].w = w;
        Edges[k].next = head[i];
        head[i] = k;
    }
    for(int i  = 0;i<n ;i++) cout<<indegree[i]<<" ";
    cout<<endl;
    cout<<"edge"<<endl;
    for(int i = 0;i<m;i++)
    {
        cout<<i<<" "<<Edges[i].to<<" "<<Edges[i].w<<endl;
    }
    cout<<endl;
    cout<<"head[7]:"<<head[7]<<endl;
    for(int i =0;i<=n-1;i++)
    {
        for(k = head[i];k!=-1;k=Edges[k].next)
        {
            cout<<i<<" "<<Edges[k].to<<" "<<Edges[k].w<<endl;
        }
    }
    cout<<endl;
    cout<<"head"<<endl;
    for(int i= 0;i<n;i++)
        cout<<head[i]<<" ";
        cout<<endl;
    //cout<<"DFS1"<<endl;
   // for(int i = 0;i<n-1;i++)
     //   if(!s[i])
     //       DFS1(0);
    //cout<<"tuopu"<<endl;
   // tuopu();
   DFS1(0);

    for(int i =0;ans[i]!=-1;i++)
    {
        cout<<ans[i]<<" ";
    }
    cout << "\nHello world!" << endl;
    return 0;
}
