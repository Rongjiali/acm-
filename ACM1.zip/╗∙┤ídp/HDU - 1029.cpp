//#include<bits/stdc++.h>
//using namespace std;
//
//const int N = 1e6+10;
//int a[N];
//
//int main()
//{
//    int n ;
//    while(~scanf("%d",&n))
//    {
//        int num = 0;
//        int ans = -1;
//        for(int i =0;i<n;i++)
//        {
//            scanf("%d",&a[i]);
//            if(num==0)
//            {
//                num++;
//                ans = a[i];
//            }
//            else
//            {
//                if(ans!=a[i])
//                    num--;
//                else
//                    num++;
//            }
//        }
//        printf("%d\n",ans);
//    }
//}
