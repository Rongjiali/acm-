#include<bits/stdc++.h>
#include<iostream>
#include<cstdio>
#include<stdlib.h>
#include<string>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
#define inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f
#define IO ios::sync_with_stdio(0)
typedef pair<int, int> P;
const int maxn = 2e5+5;
const ll mod = 1e9+7;
using namespace std;

int a[maxn];
int main()
{
    int m;
    cin>>m;
    for(int i=0;i<m;i++)
        cin>>a[i];
    int sum = 0,summax= 0;
    for(int i=0;i<m;i++)
    {
        sum+=a[i];
        if(sum>summax) summax = sum;
        else if(sum<0) sum=0;
    }
    printf("%d\n",summax);
}
