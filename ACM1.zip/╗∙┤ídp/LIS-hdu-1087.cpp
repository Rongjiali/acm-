//#include<bits/stdc++.h>
//using namespace std;
//int a[1010];
//int dp[1010];
//int main()
//{
//    int n;
//    while(scanf("%d",&n),n)
//    {
//        int ans = 0;
//        for(int i =0;i<n;i++)
//        {
//            scanf("%d",&a[i]);
//        }
//        for(int i=0;i<n;i++)
//        {
//            dp[i] = a[i];
//            for(int j=0;j<i;j++)
//            {
//                if(a[j]<a[i])
//                {
//                    dp[i] = max(dp[i],dp[j]+a[i]);
//                }
//            }
//            ans = max(dp[i],ans);
//
//        }
//        printf("%d\n",ans);
//    }
//}
