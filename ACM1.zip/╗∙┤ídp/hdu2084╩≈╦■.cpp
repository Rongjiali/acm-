//#include<bits/stdc++.h>
//using namespace std;
//int a[110][110];
//int dp[110][110];
//int main()
//{
//    int t;
//    scanf("%d",&t);
//
//    while(t--)
//    {
//        int n;
//        cin>>n;
//        memset(a,0,sizeof(a));
//        memset(dp,0,sizeof(dp));
//        for(int i=1;i<=n;i++)
//        {
//            for(int j=1;j<=i;j++)
//            {
//                scanf("%d",&a[i][j]);
//
//            }
//        }
//        int ans = 0;
//        for(int i=1;i<=n;i++)
//        {
//            for(int j=1;j<=i;j++)
//            {
//                dp[i][j] = max(dp[i-1][j],dp[i-1][j-1])+a[i][j];
//                ans = max(dp[i][j],ans);
//            }
//        }
//        printf("%d\n",ans);
//
//
//    }
//    return 0;
//}
