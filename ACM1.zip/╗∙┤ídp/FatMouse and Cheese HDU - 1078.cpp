#include<bits/stdc++.h>
using namespace std;
const int manx=2e3+5;
int dp[manx][manx],a[manx][manx];
int dx[4]={0,0,-1,1},dy[4]={1,-1,0,0};
int n,k;
int dfs(int x,int y)
{
    int mx = 0;
    for(int i=1;i<=k;i++)
    {
        for(int j =0;j<4;j++)
        {
            int xx = x+dx[j]*i,yy = y+dy[j]*i;
            if(a[x][y]<a[xx][yy] && xx>0 &&yy>0 &&  xx<=n&&yy<=n)
                mx = max(dfs(xx,yy),mx);
        }

    }
    return dp[x][y] = a[x][y] + mx;
}
int main()
{

    while(scanf("%d%d",&n,&k)!=EOF)
    {
        if(n==-1 &&k==-1) break;
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                scanf("%d",&a[i][j]);
        memset(dp,0,sizeof(dp));
        printf("%d\n",dfs(1,1));
    }
}
